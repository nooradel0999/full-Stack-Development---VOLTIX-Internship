# NexaTech Solutions — Task 4: User Registration & Authentication

نظام تسجيل مستخدمين ومصادقة كامل (Full-Stack) مبني على الـ Backend والقاعدة البيانات من Task 3.

## التشغيل

### الطريقة الأسهل (ويندوز):
شغّل ملف `run.bat` بالدبل-كليك.

### يدوياً:
```bash
cd server
npm install      # مرة واحدة فقط
node server.js
```

ثم افتح:
- الموقع: http://localhost:3000
- تسجيل الدخول: http://localhost:3000/login.html
- إنشاء حساب: http://localhost:3000/register.html
- حسابي (محمية): http://localhost:3000/profile.html
- لوحة الإدارة (محمية): http://localhost:3000/admin
- بيانات دخول المدير: **admin / admin123**

## مزايا الأمان المطبقة (Task 4)
- تشفير كلمات المرور بخوارزمية **scrypt** مع Salt عشوائي، والمقارنة بـ `timingSafeEqual`.
- ترقية تلقائية لكلمات مرور Task 3 القديمة (SHA-256 بلا Salt) عند أول تسجيل دخول ناجح.
- تحقق كامل من المدخلات في الـ Backend (اسم مستخدم 3-20، بريد صالح، كلمة مرور 8+ حرف ورقم، تطابق التأكيد، عدم التكرار).
- **Rate Limiting**: 5 محاولات دخول فاشلة لكل (مستخدم + IP) خلال 10 دقائق.
- رسالة خطأ عامة عند فشل الدخول (لا تكشف هل الخطأ في الاسم أم كلمة المرور).
- جلسات بتوكن عشوائي 32 بايت + كوكي **HttpOnly** صالح 7 أيام مع انزلاق التمديد.
- حماية الصفحات من الخادم: `/profile.html` و`/admin` تُحوَّل تلقائياً إلى صفحة الدخول بدون جلسة صالحة (لا يمكن تجاوزها من الـ JavaScript).
- ترويسات أمان: `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`.

## البنية
```
nexatech/
├── index.html              الموقع الرئيسي
├── login.html              تسجيل الدخول
├── register.html           إنشاء حساب جديد
├── profile.html            صفحة حسابي (محمية)
├── css/  js/  images/      ملفات الموقع
├── admin/index.html        لوحة إدارة المحتوى (محمية - مدير فقط)
├── server/server.js        الـ Backend (Express + REST API + Auth)
├── server/package.json     الاعتماديات
├── data/nexatech.db        قاعدة بيانات SQLite (تُنشأ تلقائياً)
└── run.bat                 ملف تشغيل سريع
```

## الـ API
| Method | Endpoint | الوظيفة | الحماية |
|---|---|---|---|
| POST | /api/register | إنشاء حساب جديد | عام |
| POST | /api/login | تسجيل الدخول | عام + Rate Limit |
| POST | /api/logout | تسجيل الخروج | مسجل |
| GET | /api/me | بيانات المستخدم الحالي | مسجل |
| PUT | /api/profile | تحديث الاسم/البريد | مسجل |
| POST | /api/password | تغيير كلمة المرور | مسجل |
| GET | /api/users | قائمة المستخدمين | مدير فقط |
| DELETE | /api/users/:id | حذف مستخدم | مدير فقط |
| GET/POST/PUT/DELETE | /api/content... | إدارة المحتوى (Task 3) | كتابة: مسجل |
| GET/POST/DELETE | /api/messages... | رسائل التواصل (Task 3) | قراءة/حذف: مسجل |
| GET | /api/stats | إحصائيات | عام |

## قاعدة البيانات
جداول: `users` (id, username, email, password_hash, full_name, role, created_at, last_login)، `content_items`، `messages`.

إعداد: Nooraleeman Adel Al-shawesh — VOLTIX Internship — 16/9/2026
