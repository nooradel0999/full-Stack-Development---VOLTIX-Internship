/**
 * NexaTech Solutions - User Registration & Authentication Backend (Task 4)
 * Express + SQLite (sql.js) - Full-Stack Auth System
 * Author: Nooraleeman Adel Al-shawesh
 * Program: VOLTIX Internship
 * Date: September 2026
 *
 * Security features:
 *   - scrypt salted password hashing (with automatic legacy SHA-256 migration)
 *   - Server-side validation for every input
 *   - Random 32-byte session tokens with 7-day expiry + httpOnly cookie
 *   - Login rate limiting (5 attempts / 10 min per username+IP)
 *   - Protected pages (/admin, /profile.html) & protected API routes
 *
 * Run:  node server.js
 * Then open:
 *   - Website:      http://localhost:3000
 *   - Login:        http://localhost:3000/login.html
 *   - Register:     http://localhost:3000/register.html
 *   - My Account:   http://localhost:3000/profile.html  (protected)
 *   - Admin Panel:  http://localhost:3000/admin         (protected)
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const initSqlJs = require('sql.js');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const DB_PATH = path.join(ROOT, 'data', 'nexatech.db');

const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const COOKIE_NAME = 'nexa_session';

// ==================== DATABASE (SQLite) ====================
let db;

async function loadDatabase() {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    const SQL = await initSqlJs();
    if (fs.existsSync(DB_PATH)) {
        const filebuffer = fs.readFileSync(DB_PATH);
        db = new SQL.Database(filebuffer);
        console.log('✓ Database loaded from data/nexatech.db');
    } else {
        db = new SQL.Database();
        console.log('✓ New database created');
    }
    createTables();
    seedDatabase();
    saveDatabase();
}

function saveDatabase() {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function createTables() {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT DEFAULT 'user' CHECK(role IN ('user','admin')),
            created_at TEXT DEFAULT (datetime('now')),
            last_login TEXT
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS content_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            image TEXT,
            icon TEXT,
            status TEXT DEFAULT 'published' CHECK(status IN ('published','draft')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            subject TEXT,
            message TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
    `);
}

// ==================== PASSWORD SECURITY ====================
/**
 * Hash a password with scrypt + random 16-byte salt.
 * Format stored in DB:  scrypt$N$salt_hex$hash_hex
 */
function hashPassword(password) {
    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
    return `scrypt$16384$${salt.toString('hex')}$${hash.toString('hex')}`;
}

/**
 * Verify a password against a stored hash.
 * Supports the new scrypt format and the legacy plain SHA-256 format
 * (Task 3 database) — legacy hashes are transparently upgraded on login.
 */
function verifyPassword(password, stored) {
    if (!stored) return false;
    try {
        if (stored.startsWith('scrypt$')) {
            const [, nStr, saltHex, hashHex] = stored.split('$');
            const salt = Buffer.from(saltHex, 'hex');
            const expected = Buffer.from(hashHex, 'hex');
            const actual = crypto.scryptSync(password, salt, 64, { N: parseInt(nStr, 10), r: 8, p: 1 });
            return crypto.timingSafeEqual(actual, expected);
        }
        // Legacy SHA-256 (no salt) — Task 3 compatibility
        const legacy = crypto.createHash('sha256').update(password).digest('hex');
        return crypto.timingSafeEqual(Buffer.from(legacy, 'hex'), Buffer.from(stored, 'hex'));
    } catch {
        return false;
    }
}

function isLegacyHash(stored) {
    return stored && !stored.startsWith('scrypt$');
}

// ==================== SEED DATA ====================
function seedDatabase() {
    const users = db.exec("SELECT COUNT(*) AS c FROM users");
    if (users[0].values[0][0] === 0) {
        db.run("INSERT INTO users (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)",
            ['admin', 'admin@nexatech.com', hashPassword('admin123'), 'Nooraleeman Adel Al-shawesh', 'admin']);
        console.log('✓ Default admin user created (admin / admin123)');
    }

    const items = db.exec("SELECT COUNT(*) AS c FROM content_items");
    if (items[0].values[0][0] === 0) {
        const seed = [
            ['Web Development', 'service', 'Custom web applications built with modern frameworks and best practices.', 'images/web-dev.png', 'fa-code', 'published'],
            ['Mobile Apps', 'service', 'Native and cross-platform mobile applications for iOS and Android.', 'images/mobile-app.png', 'fa-mobile-alt', 'published'],
            ['Cloud Solutions', 'service', 'Scalable cloud infrastructure and migration services.', 'images/cloud-computing.png', 'fa-cloud', 'published'],
            ['Digital Marketing', 'service', 'Data-driven marketing strategies that increase visibility and conversions.', 'images/digital-marketing.png', 'fa-bullhorn', 'published'],
            ['UI/UX Design', 'service', 'Beautiful, intuitive interfaces that delight users.', 'images/marketing-3d.png', 'fa-paint-brush', 'published'],
            ['IT Consulting', 'service', 'Strategic technology consulting to align IT with business goals.', 'images/team-coding.png', 'fa-chart-pie', 'published'],
            ['E-Commerce Platform', 'project', 'Full-stack web application', 'images/web-dev.png', null, 'published'],
            ['Travel Booking App', 'project', 'Cross-platform mobile app', 'images/mobile-app.png', null, 'published'],
            ['Cloud Migration', 'project', 'Enterprise cloud solution', 'images/cloud-computing.png', null, 'published'],
            ['Marketing Dashboard', 'project', 'Analytics platform', 'images/digital-marketing.png', null, 'draft'],
        ];
        const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
        seed.forEach(row => stmt.run(row));
        stmt.free();
        console.log('✓ Content items seeded');
    }
}

function queryAll(sql, params = []) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
}

function queryOne(sql, params = []) {
    return queryAll(sql, params)[0] || null;
}

// ==================== SESSIONS ====================
const sessions = {}; // token -> { userId, expires }

function createSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    sessions[token] = { userId, expires: Date.now() + SESSION_TTL_MS };
    return token;
}

function getSessionUser(token) {
    const session = sessions[token];
    if (!session) return null;
    if (session.expires < Date.now()) {
        delete sessions[token];
        return null;
    }
    // sliding expiration
    session.expires = Date.now() + SESSION_TTL_MS;
    const user = queryOne("SELECT id, username, email, full_name, role, created_at, last_login FROM users WHERE id = ?", [session.userId]);
    return user || null;
}

function destroySession(token) {
    delete sessions[token];
}

// Login rate limiting: max 5 failed attempts per (username+IP) per 10 minutes
const loginAttempts = {};
const MAX_ATTEMPTS = 5;
const ATTEMPT_WINDOW_MS = 10 * 60 * 1000;

function isRateLimited(key) {
    const rec = loginAttempts[key];
    if (!rec) return false;
    if (Date.now() - rec.first > ATTEMPT_WINDOW_MS) {
        delete loginAttempts[key];
        return false;
    }
    return rec.count >= MAX_ATTEMPTS;
}

function recordFailedAttempt(key) {
    const rec = loginAttempts[key];
    if (!rec || Date.now() - rec.first > ATTEMPT_WINDOW_MS) {
        loginAttempts[key] = { count: 1, first: Date.now() };
    } else {
        rec.count += 1;
    }
}

// ==================== VALIDATION ====================
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validateRegistration({ username, email, fullName, password, confirmPassword }) {
    const errors = [];
    username = String(username || '').trim();
    email = String(email || '').trim().toLowerCase();
    fullName = String(fullName || '').trim();

    if (!USERNAME_RE.test(username)) errors.push('اسم المستخدم: 3-20 حرفاً (أحرف إنجليزية، أرقام، _)');
    if (!EMAIL_RE.test(email) || email.length > 120) errors.push('البريد الإلكتروني غير صالح');
    if (fullName.length < 3 || fullName.length > 80) errors.push('الاسم الكامل: 3-80 حرفاً');
    if (typeof password !== 'string' || password.length < 8 || password.length > 72) errors.push('كلمة المرور: 8 أحرف على الأقل');
    else if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) errors.push('كلمة المرور يجب أن تحتوي حرفاً ورقماً على الأقل');
    if (password !== confirmPassword) errors.push('كلمتا المرور غير متطابقتين');

    return { errors, username, email, fullName };
}

// ==================== MIDDLEWARE ====================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Security headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    next();
});

function parseCookies(req) {
    const header = req.headers.cookie || '';
    const out = {};
    header.split(';').forEach(pair => {
        const idx = pair.indexOf('=');
        if (idx > -1) out[pair.slice(0, idx).trim()] = decodeURIComponent(pair.slice(idx + 1).trim());
    });
    return out;
}

function tokenFromRequest(req) {
    const auth = req.headers['authorization'];
    if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
    return parseCookies(req)[COOKIE_NAME] || null;
}

// API auth guard -> 401 JSON
function requireAuth(req, res, next) {
    const user = getSessionUser(tokenFromRequest(req));
    if (!user) {
        return res.status(401).json({ success: false, message: 'غير مصرح - يرجى تسجيل الدخول أولاً' });
    }
    req.user = user;
    next();
}

// Admin-only guard
function requireAdmin(req, res, next) {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'هذه الصفحة تتطلب صلاحية مدير' });
    }
    next();
}

// Page guard -> redirect to login (uses the httpOnly cookie so it cannot be bypassed from JS)
function requirePageAuth(req, res, next) {
    const user = getSessionUser(parseCookies(req)[COOKIE_NAME]);
    if (!user) return res.redirect('/login.html?next=' + encodeURIComponent(req.originalUrl));
    req.user = user;
    next();
}

// Protected pages (Task 4 requirement: pages only for authenticated users)
// NOTE: mounted BEFORE express.static so the guard runs before files are served
app.use('/profile.html', requirePageAuth);
app.use('/admin', requirePageAuth, requireAdmin);

// Serve static files (website + admin + images)
app.use(express.static(ROOT));

// ==================== AUTH API (TASK 4) ====================

// REGISTER — create a new account
app.post('/api/register', (req, res) => {
    const { errors, username, email, fullName } = validateRegistration(req.body);
    const password = req.body.password;

    if (errors.length) {
        return res.status(400).json({ success: false, message: 'يرجى تصحيح الأخطاء التالية', errors });
    }
    if (queryOne("SELECT id FROM users WHERE username = ?", [username])) {
        return res.status(409).json({ success: false, message: 'اسم المستخدم مستخدم مسبقاً', errors: ['اسم المستخدم مستخدم مسبقاً'] });
    }
    if (queryOne("SELECT id FROM users WHERE email = ?", [email])) {
        return res.status(409).json({ success: false, message: 'البريد الإلكتروني مسجل مسبقاً', errors: ['البريد الإلكتروني مسجل مسبقاً'] });
    }

    db.run("INSERT INTO users (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, 'user')",
        [username, email, hashPassword(password), fullName]);
    saveDatabase();

    const user = queryOne("SELECT id, username, email, full_name, role, created_at FROM users WHERE username = ?", [username]);
    const token = createSession(user.id);
    res.cookie = null; // no-op clarity
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=${token}; HttpOnly; Path=/; Max-Age=${SESSION_TTL_MS / 1000}; SameSite=Lax`);
    res.status(201).json({ success: true, message: 'تم إنشاء الحساب بنجاح، أهلاً بك!', token, user });
});

// LOGIN — authenticate with credentials
app.post('/api/login', (req, res) => {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const rateKey = `${username.toLowerCase()}|${ip}`;

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'يرجى إدخال اسم المستخدم وكلمة المرور' });
    }
    if (isRateLimited(rateKey)) {
        return res.status(429).json({ success: false, message: 'محاولات كثيرة، يرجى الانتظار 10 دقائق ثم المحاولة مجدداً' });
    }

    const user = queryOne("SELECT * FROM users WHERE username = ? OR email = ?", [username, username.toLowerCase()]);
    if (!user || !verifyPassword(password, user.password_hash)) {
        recordFailedAttempt(rateKey);
        // Generic message — do not reveal whether the username or the password was wrong
        return res.status(401).json({ success: false, message: 'بيانات الدخول غير صحيحة' });
    }

    // Transparent upgrade of legacy (unsalted) password hashes
    if (isLegacyHash(user.password_hash)) {
        db.run("UPDATE users SET password_hash = ? WHERE id = ?", [hashPassword(password), user.id]);
        saveDatabase();
        console.log(`✓ Password hash upgraded to scrypt for user: ${user.username}`);
    }

    delete loginAttempts[rateKey];
    db.run("UPDATE users SET last_login = datetime('now') WHERE id = ?", [user.id]);
    saveDatabase();

    const token = createSession(user.id);
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=${token}; HttpOnly; Path=/; Max-Age=${SESSION_TTL_MS / 1000}; SameSite=Lax`);
    res.json({
        success: true,
        message: 'تم تسجيل الدخول بنجاح',
        token,
        user: { id: user.id, username: user.username, email: user.email, full_name: user.full_name, role: user.role }
    });
});

// LOGOUT
app.post('/api/logout', requireAuth, (req, res) => {
    destroySession(tokenFromRequest(req));
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`);
    res.json({ success: true, message: 'تم تسجيل الخروج بنجاح' });
});

// CURRENT USER
app.get('/api/me', requireAuth, (req, res) => {
    res.json({ success: true, user: req.user });
});

// UPDATE PROFILE (full name / email) — authenticated
app.put('/api/profile', requireAuth, (req, res) => {
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const errors = [];
    if (fullName.length < 3 || fullName.length > 80) errors.push('الاسم الكامل: 3-80 حرفاً');
    if (!EMAIL_RE.test(email) || email.length > 120) errors.push('البريد الإلكتروني غير صالح');
    const taken = queryOne("SELECT id FROM users WHERE email = ? AND id != ?", [email, req.user.id]);
    if (taken) errors.push('البريد الإلكتروني مسجل لحساب آخر');
    if (errors.length) return res.status(400).json({ success: false, message: 'فشل التحديث', errors });

    db.run("UPDATE users SET full_name = ?, email = ? WHERE id = ?", [fullName, email, req.user.id]);
    saveDatabase();
    const user = queryOne("SELECT id, username, email, full_name, role, created_at FROM users WHERE id = ?", [req.user.id]);
    res.json({ success: true, message: 'تم تحديث الملف الشخصي بنجاح', user });
});

// CHANGE PASSWORD — authenticated, requires current password
app.post('/api/password', requireAuth, (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const user = queryOne("SELECT * FROM users WHERE id = ?", [req.user.id]);
    if (!verifyPassword(String(currentPassword || ''), user.password_hash)) {
        return res.status(401).json({ success: false, message: 'كلمة المرور الحالية غير صحيحة' });
    }
    if (typeof newPassword !== 'string' || newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return res.status(400).json({ success: false, message: 'كلمة المرور الجديدة: 8 أحرف على الأقل وتحتوي حرفاً ورقماً' });
    }
    db.run("UPDATE users SET password_hash = ? WHERE id = ?", [hashPassword(newPassword), req.user.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
});

// LIST USERS — admin only
app.get('/api/users', requireAuth, requireAdmin, (req, res) => {
    res.json({ success: true, data: queryAll("SELECT id, username, email, full_name, role, created_at, last_login FROM users ORDER BY id") });
});

// DELETE USER — admin only (cannot delete self / last admin)
app.delete('/api/users/:id', requireAuth, requireAdmin, (req, res) => {
    const target = queryOne("SELECT * FROM users WHERE id = ?", [req.params.id]);
    if (!target) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    if (target.id === req.user.id) return res.status(400).json({ success: false, message: 'لا يمكنك حذف حسابك الحالي' });
    if (target.role === 'admin') {
        const admins = queryOne("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'")['c'];
        if (admins <= 1) return res.status(400).json({ success: false, message: 'لا يمكن حذف آخر مدير في النظام' });
    }
    db.run("DELETE FROM users WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف المستخدم بنجاح' });
});

// ==================== CONTENT CRUD API (Task 3 - kept) ====================

app.get('/api/content', (req, res) => {
    const { category, status, search } = req.query;
    let sql = "SELECT * FROM content_items WHERE 1=1";
    const params = [];
    if (category) { sql += " AND category = ?"; params.push(category); }
    if (status) { sql += " AND status = ?"; params.push(status); }
    if (search) { sql += " AND (title LIKE ? OR description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }
    sql += " ORDER BY id DESC";
    res.json({ success: true, data: queryAll(sql, params) });
});

app.get('/api/content/:id', (req, res) => {
    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    if (!item) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    res.json({ success: true, data: item });
});

app.post('/api/content', requireAuth, (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    if (!title || !category) {
        return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });
    }
    const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
    stmt.run([title, category, description ?? '', image ?? 'images/web-dev.png', icon ?? null, status ?? 'published']);
    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    stmt.free();
    saveDatabase();
    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [newId]);
    res.status(201).json({ success: true, message: 'تمت إضافة العنصر بنجاح', data: item });
});

app.put('/api/content/:id', requireAuth, (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    if (!title || !category) {
        return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });
    }
    db.run(
        "UPDATE content_items SET title = ?, category = ?, description = ?, image = ?, icon = ?, status = ?, updated_at = datetime('now') WHERE id = ?",
        [title, category, description || '', image || '', icon || null, status || 'published', req.params.id]
    );
    saveDatabase();
    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: 'تم تحديث العنصر بنجاح', data: item });
});

app.delete('/api/content/:id', requireAuth, (req, res) => {
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    db.run("DELETE FROM content_items WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف العنصر بنجاح' });
});

// ==================== STATS / MESSAGES API (Task 3 - kept) ====================
app.get('/api/stats', (req, res) => {
    const total = queryOne("SELECT COUNT(*) AS c FROM content_items")['c'];
    const published = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'published'")['c'];
    const drafts = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'draft'")['c'];
    const byCategory = queryAll("SELECT category, COUNT(*) AS count FROM content_items GROUP BY category");
    const usersCount = queryOne("SELECT COUNT(*) AS c FROM users")['c'];
    res.json({ success: true, data: { total, published, drafts, byCategory, users: usersCount } });
});

app.post('/api/messages', (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    if (!name || !email || !message) {
        return res.status(400).json({ success: false, message: 'الاسم والبريد والرسالة مطلوبة' });
    }
    db.run("INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)",
        [name, email, phone || '', subject || '', message]);
    saveDatabase();
    res.status(201).json({ success: true, message: 'تم إرسال رسالتك بنجاح' });
});

app.get('/api/messages', requireAuth, (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM messages ORDER BY id DESC") });
});

app.delete('/api/messages/:id', requireAuth, (req, res) => {
    db.run("DELETE FROM messages WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الرسالة' });
});

// ==================== START ====================
app.get('/api/health', (req, res) => res.json({ success: true, status: 'running' }));

app.listen(PORT, async () => {
    await loadDatabase();
    console.log('=================================================');
    console.log('  NexaTech Solutions - Task 4: Auth System');
    console.log(`  Website:      http://localhost:${PORT}`);
    console.log(`  Login:        http://localhost:${PORT}/login.html`);
    console.log(`  Register:     http://localhost:${PORT}/register.html`);
    console.log(`  My Account:   http://localhost:${PORT}/profile.html  (protected)`);
    console.log(`  Admin Panel:  http://localhost:${PORT}/admin         (protected)`);
    console.log('  Admin Login:  admin / admin123');
    console.log('=================================================');
});
