@echo off
title NexaTech - Task 4: Authentication Server
cd /d "%~dp0server"
echo ==========================================
echo   NexaTech Solutions - Task 4
echo   Starting server...
echo   Website:    http://localhost:3000
echo   Login:      http://localhost:3000/login.html
echo   Register:   http://localhost:3000/register.html
echo   My Account: http://localhost:3000/profile.html (protected)
echo   Admin:      http://localhost:3000/admin (protected)
echo   Admin login: admin / admin123
echo ==========================================
if not exist node_modules (
    echo Installing dependencies (first time only)...
    call npm install
)
node server.js
pause
