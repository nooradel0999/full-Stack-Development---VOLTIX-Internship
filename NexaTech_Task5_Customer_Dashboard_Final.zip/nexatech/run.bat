@echo off
title NexaTech - Full Stack Server
cd /d "%~dp0server"
echo ==========================================
echo   NexaTech Solutions - Task 3 + Task 5
echo   Starting server...
echo   Website:     http://localhost:3000
echo   Customer Dashboard: http://localhost:3000/dashboard.html
echo   Admin Panel: http://localhost:3000/admin
echo   Login: admin / admin123
echo ==========================================
if not exist node_modules (
    echo Installing dependencies (first time only)...
    call npm install
)
node server.js
pause
