# NexaTech Solutions — Task 3 + Task 5

نظام Full Stack متكامل يحتوي على:

- الموقع الرئيسي.
- نظام Authentication: تسجيل دخول وإنشاء حساب.
- Customer Dashboard محمية ومتصلة بالـ Backend وقاعدة بيانات SQLite.
- لوحة إدارة المحتوى للمدير.

## طريقة التشغيل

### ويندوز
شغّل `run.bat` بالدبل-كليك.

### يدويًا
```bash
cd server
npm install
npm start
```

ثم افتح:

- الموقع: http://localhost:3000
- لوحة العميل: http://localhost:3000/dashboard.html
- لوحة الإدارة: http://localhost:3000/admin
- بيانات المدير: `admin / admin123`

## ملاحظات Task 5 — Customer Dashboard

- لا يمكن الوصول إلى Dashboard بدون تسجيل الدخول.
- بيانات المستخدم تُجلب من `/api/me` و`/api/dashboard` من قاعدة البيانات.
- يستطيع المستخدم تعديل: الاسم الكامل، البريد الإلكتروني، رقم الهاتف.
- يستطيع المستخدم تغيير كلمة المرور بعد إدخال كلمة المرور الحالية.
- اسم المستخدم والدور وتاريخ الإنشاء للعرض فقط.
- Dashboard تتصل بجداول: `users` و`messages` و`content_items`.

## الـ API المضاف لـ Task 5

| Method | Endpoint | الوظيفة |
|---|---|---|
| POST | `/api/register` | إنشاء حساب عميل |
| POST | `/api/login` | تسجيل الدخول باسم المستخدم أو البريد |
| POST | `/api/logout` | تسجيل الخروج |
| GET | `/api/me` | بيانات المستخدم الحالي |
| PUT | `/api/profile` | تعديل بيانات الحساب |
| POST | `/api/password` | تغيير كلمة المرور |
| GET | `/api/dashboard` | بيانات Dashboard من قاعدة البيانات |

## قاعدة البيانات

جداول النظام:

- `users`
- `content_items`
- `messages`

الملف: `data/nexatech.db` ويُنشأ تلقائيًا عند أول تشغيل.

إعداد: Nooraleeman Adel Al-shawesh — September 2026
