
// ==================== TASK 10: FILE & DOCUMENT MANAGEMENT API ====================
// Authenticated upload -> server-side validation -> disk storage + DB record.
// Listing / download / delete are all permission-checked (integrated with Task 9 RBAC).

const ALLOWED_EXTENSIONS = new Set([
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',   // documents
    'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg',           // images
    'txt', 'csv', 'zip'                                   // misc
]);
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const FILE_CATEGORIES = ['general', 'contract', 'invoice', 'design', 'report', 'other'];

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
        // Stored with a random name; original name is kept in the DB.
        const ext = (file.originalname.split('.').pop() || '').toLowerCase();
        cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: MAX_FILE_SIZE, files: 1 },
    fileFilter: (req, file, cb) => {
        const ext = (file.originalname.split('.').pop() || '').toLowerCase();
        if (!ALLOWED_EXTENSIONS.has(ext)) {
            return cb(new Error(`نوع الملف غير مسموح (.${ext}) — الأنواع المسموحة: ${[...ALLOWED_EXTENSIONS].join(', ')}`));
        }
        cb(null, true);
    }
});

function fileRecord(f, uploader) {
    return {
        id: f.id,
        original_name: f.original_name,
        mime_type: f.mime_type,
        size: f.size,
        extension: f.extension,
        category: f.category,
        description: f.description,
        created_at: f.created_at,
        uploader_id: f.user_id,
        uploader_name: uploader?.full_name || f.uploader_name || null,
        uploader_username: uploader?.username || f.uploader_username || null
    };
}

function removeFileFromDisk(storedName) {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, storedName)); } catch (e) { /* already gone */ }
}

// Upload a file (authenticated + files.upload permission)
app.post('/api/files', requireAuth, requirePermission('files.upload'), (req, res) => {
    upload.single('file')(req, res, (err) => {
        if (err) {
            const msg = err.code === 'LIMIT_FILE_SIZE'
                ? `حجم الملف يتجاوز الحد الأقصى المسموح (${MAX_FILE_SIZE / 1024 / 1024}MB)`
                : (err.message || 'فشل معالجة الملف');
            return res.status(400).json({ success: false, message: msg });
        }
        if (!req.file) {
            return res.status(400).json({ success: false, message: 'لم يتم إرفاق أي ملف — حقل "file" مطلوب' });
        }

        const category = FILE_CATEGORIES.includes(req.body.category) ? req.body.category : 'general';
        const description = (req.body.description || '').trim().slice(0, 500);
        const ext = (req.file.originalname.split('.').pop() || '').toLowerCase();
        // Decode latin1 -> utf8 so Arabic original filenames survive multipart transport
        const originalName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');

        db.run(`INSERT INTO files (user_id, original_name, stored_name, mime_type, size, extension, category, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.user.id, originalName, req.file.filename, req.file.mimetype, req.file.size, ext, category, description]);
        saveDatabase();

        const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
        const f = queryOne("SELECT * FROM files WHERE id = ?", [newId]);
        res.status(201).json({ success: true, message: 'تم رفع الملف بنجاح', data: fileRecord(f, req.user) });
    });
});

// My files (files.view.own)
app.get('/api/files/mine', requireAuth, requirePermission('files.view.own'), (req, res) => {
    const rows = queryAll("SELECT * FROM files WHERE user_id = ? ORDER BY id DESC", [req.user.id]);
    res.json({ success: true, data: rows.map(f => fileRecord(f, req.user)) });
});

// All files (files.view.all — company side)
app.get('/api/files', requireAuth, requirePermission('files.view.all'), (req, res) => {
    const { search, category, user_id } = req.query;
    let sql = `SELECT f.*, u.full_name AS uploader_name, u.username AS uploader_username
               FROM files f JOIN users u ON u.id = f.user_id WHERE 1=1`;
    const params = [];
    if (search && search.trim()) { sql += " AND (f.original_name LIKE ? OR f.description LIKE ?)"; params.push(`%${search.trim()}%`, `%${search.trim()}%`); }
    if (category && FILE_CATEGORIES.includes(category)) { sql += " AND f.category = ?"; params.push(category); }
    if (user_id && !isNaN(parseInt(user_id))) { sql += " AND f.user_id = ?"; params.push(parseInt(user_id)); }
    sql += " ORDER BY f.id DESC";
    res.json({ success: true, data: queryAll(sql, params).map(f => fileRecord(f)) });
});

// Download (owner OR anyone with files.view.all)
app.get('/api/files/:id/download', requireAuth, (req, res) => {
    const f = queryOne("SELECT * FROM files WHERE id = ?", [req.params.id]);
    if (!f) return res.status(404).json({ success: false, message: 'الملف غير موجود' });
    if (f.user_id !== req.user.id && !hasPermission(req.user, 'files.view.all')) {
        return res.status(403).json({ success: false, message: 'لا يمكنك تحميل ملفات مستخدمين آخرين' });
    }
    const full = path.join(UPLOAD_DIR, f.stored_name);
    if (!fs.existsSync(full)) return res.status(410).json({ success: false, message: 'الملف مفقود من وحدة التخزين' });
    res.download(full, f.original_name);
});

// Delete (owner + files.delete.own, or files.delete.any for admins)
app.delete('/api/files/:id', requireAuth, (req, res) => {
    const f = queryOne("SELECT * FROM files WHERE id = ?", [req.params.id]);
    if (!f) return res.status(404).json({ success: false, message: 'الملف غير موجود' });

    const isOwner = f.user_id === req.user.id;
    const allowed = (isOwner && hasPermission(req.user, 'files.delete.own')) || hasPermission(req.user, 'files.delete.any');
    if (!allowed) {
        return res.status(403).json({ success: false, message: 'لا يمكنك حذف هذا الملف — يتطلب ملكية الملف أو صلاحية files.delete.any' });
    }

    db.run("DELETE FROM files WHERE id = ?", [f.id]);
    removeFileFromDisk(f.stored_name);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الملف بنجاح' });
});
