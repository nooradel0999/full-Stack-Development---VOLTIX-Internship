@echo off
title NexaTech - Full Stack Server
cd /d "%~dp0server"
echo ==========================================
echo   NexaTech Solutions - Tasks 3 to 11
echo   Starting server...
echo   Website:            http://localhost:3000
echo   Projects Platform:  http://localhost:3000/projects.html
echo   Projects Admin:     http://localhost:3000/admin/projects.html
echo   Customer Dashboard: http://localhost:3000/dashboard.html
echo   Send Request:       http://localhost:3000/request.html
echo   Admin Panel:        http://localhost:3000/admin
echo   Users ^& Roles:      http://localhost:3000/admin/users.html
echo   My Files:           http://localhost:3000/files.html
echo   All Files:          http://localhost:3000/admin/files.html
echo   Login: admin / admin123  (employee1 / Emp12345, customer1 / Demo1234)
echo ==========================================
if not exist node_modules (
    echo Installing dependencies (first time only)...
    call npm install
)
node server.js
pause
