/**
 * NexaTech Solutions - Full Stack Platform
 * Task 3: Content Management + Task 5: Customer Dashboard
 * Task 6: Company Service Management (Services CRUD + Public Website sync)
 * Task 7: Customer Request Management (Customer-side submission + Company-side management)
 * Task 8: Search & Filtering for Company Data (Backend-driven search + multi-criteria filters)
 * Task 9: Role-Based Access Control (RBAC) — roles, permissions, backend enforcement
 * Task 10: File & Document Management — authenticated upload, storage, listing, download, delete, validation
 * Task 11: Client Project Management — clients, projects, progress, assignment and scoped dashboards
 * Express + SQLite (sql.js)
 * Author: Nooraleeman Adel Al-shawesh
 * Date: September 2026
 *
 * Run: npm install && node server.js
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const initSqlJs = require('sql.js');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const DB_PATH = path.join(ROOT, 'data', 'nexatech.db');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ==================== DATABASE (SQLite) ====================
let db;
const sessions = {}; // token -> safe user object
const permCache = {}; // role -> [permission codes] (invalidated on role/permission change)

async function loadDatabase() {
    const SQL = await initSqlJs();
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

    if (fs.existsSync(DB_PATH)) {
        const filebuffer = fs.readFileSync(DB_PATH);
        db = new SQL.Database(filebuffer);
        console.log('✓ Database loaded from data/nexatech.db');
    } else {
        db = new SQL.Database();
        console.log('✓ New database created');
    }

    createTables();
    migrateUsersTable();
    seedDatabase();
    saveDatabase();
}

function saveDatabase() {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function createTables() {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            role TEXT DEFAULT 'customer',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS content_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            image TEXT,
            icon TEXT,
            status TEXT DEFAULT 'published' CHECK(status IN ('published','draft')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    // ==================== TASK 6: SERVICES TABLE ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            icon TEXT DEFAULT 'fa-code',
            image TEXT,
            features TEXT,
            status TEXT DEFAULT 'active' CHECK(status IN ('active','inactive')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    // ==================== TASK 11: CLIENTS & PROJECTS TABLES ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            company TEXT,
            email TEXT,
            phone TEXT,
            user_id INTEGER,
            notes TEXT,
            status TEXT DEFAULT 'active' CHECK(status IN ('active','inactive')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            client_id INTEGER NOT NULL,
            status TEXT DEFAULT 'not_started' CHECK(status IN ('not_started','in_progress','completed','on_hold')),
            progress INTEGER DEFAULT 0 CHECK(progress >= 0 AND progress <= 100),
            start_date TEXT,
            due_date TEXT,
            created_by INTEGER,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (client_id) REFERENCES clients(id),
            FOREIGN KEY (created_by) REFERENCES users(id)
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS project_members (
            project_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            assigned_at TEXT DEFAULT (datetime('now')),
            PRIMARY KEY (project_id, user_id),
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            subject TEXT,
            message TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
    `);
    // ==================== TASK 7: CUSTOMER REQUESTS TABLE ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            service_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high')),
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_review','in_progress','completed','cancelled')),
            admin_notes TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (service_id) REFERENCES services(id)
        );
    `);
    // ==================== TASK 10: FILES TABLE ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            mime_type TEXT,
            size INTEGER DEFAULT 0,
            extension TEXT,
            category TEXT DEFAULT 'general',
            description TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    `);
    // ==================== TASK 9: RBAC TABLES ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            is_system INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            description TEXT,
            module TEXT DEFAULT 'general'
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS role_permissions (
            role_id INTEGER NOT NULL,
            permission_id INTEGER NOT NULL,
            PRIMARY KEY (role_id, permission_id),
            FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
        );
    `);
}

function ensureColumn(table, column, ddl) {
    const result = db.exec(`PRAGMA table_info(${table})`)[0];
    if (!result) return;
    const exists = result.values.some(row => row[1] === column);
    if (!exists) {
        db.run(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
        console.log(`✓ Column added: ${table}.${column}`);
    }
}

function migrateUsersTable() {
    ensureColumn('users', 'email', 'TEXT');
    ensureColumn('users', 'phone', 'TEXT');
    ensureColumn('users', 'updated_at', "TEXT DEFAULT (datetime('now'))");
    db.run("UPDATE users SET role = 'customer' WHERE role IS NULL OR role = ''");
}

// ==================== TASK 9: PERMISSION CATALOG ====================
// The full permission catalog of the platform. Each protected backend
// operation checks ONE of these codes before executing.
const PERMISSIONS = [
    // Content module (Task 3)
    { code: 'content.view',        module: 'content',     description: 'عرض عناصر المحتوى (عام)' },
    { code: 'content.manage',      module: 'content',     description: 'إضافة وتعديل وحذف عناصر المحتوى' },
    // Services module (Task 6)
    { code: 'services.view',       module: 'services',    description: 'عرض الخدمات (عام)' },
    { code: 'services.manage',     module: 'services',    description: 'إضافة وتعديل وحذف الخدمات' },
    // Requests module (Task 7)
    { code: 'requests.create',     module: 'requests',    description: 'إرسال طلب خدمة جديد' },
    { code: 'requests.view.own',   module: 'requests',    description: 'عرض طلباته الشخصية فقط' },
    { code: 'requests.update.own', module: 'requests',    description: 'تعديل أو إلغاء طلباته المعلقة' },
    { code: 'requests.view.all',   module: 'requests',    description: 'عرض كل طلبات العملاء (جهة الشركة)' },
    { code: 'requests.update.status', module: 'requests', description: 'تحديث حالة الطلب وملاحظات المعالجة' },
    // Messages module
    { code: 'messages.view',       module: 'messages',    description: 'عرض رسائل التواصل الواردة' },
    { code: 'messages.delete',     module: 'messages',    description: 'حذف رسائل التواصل' },
    // Users module (Task 9)
    { code: 'users.view',          module: 'users',       description: 'عرض قائمة المستخدمين' },
    { code: 'users.manage',        module: 'users',       description: 'تعيين وتغيير أدوار المستخدمين' },
    // Roles module (Task 9)
    { code: 'roles.manage',        module: 'roles',       description: 'إنشاء الأدوار وتعديل صلاحياتها وحذفها' },
    // Files module (Task 10)
    { code: 'files.upload',        module: 'files',       description: 'رفع ملفات ومستندات على المنصة' },
    { code: 'files.view.own',      module: 'files',       description: 'عرض ملفاته المرفوعة فقط' },
    { code: 'files.delete.own',    module: 'files',       description: 'حذف ملفاته المرفوعة فقط' },
    { code: 'files.view.all',      module: 'files',       description: 'عرض ملفات كل المستخدمين (جهة الشركة)' },
    { code: 'files.delete.any',    module: 'files',       description: 'حذف أي ملف مرفوع على المنصة' },
    // Projects module (Task 11)
    { code: 'clients.view',          module: 'projects', description: 'عرض بيانات العملاء' },
    { code: 'clients.manage',        module: 'projects', description: 'إنشاء وتعديل وحذف بيانات العملاء' },
    { code: 'projects.view.own',     module: 'projects', description: 'عرض مشاريعه أو مشاريع العميل المرتبط به فقط' },
    { code: 'projects.view.all',     module: 'projects', description: 'عرض كل مشاريع الشركة' },
    { code: 'projects.create',       module: 'projects', description: 'إنشاء مشروع جديد' },
    { code: 'projects.update',       module: 'projects', description: 'تعديل بيانات المشروع' },
    { code: 'projects.update.status',module: 'projects', description: 'تحديث حالة المشروع ونسبة تقدمه' },
    { code: 'projects.assign',       module: 'projects', description: 'تعيين المشروع إلى أعضاء الفريق' },
    { code: 'projects.delete',       module: 'projects', description: 'حذف المشروعات' },
];

// Default seeded roles and the permissions each one holds.
const DEFAULT_ROLES = [
    {
        name: 'admin',
        description: 'مدير النظام — كل الصلاحيات',
        is_system: 1,
        permissions: PERMISSIONS.map(p => p.code), // ALL permissions
    },
    {
        name: 'employee',
        description: 'موظف عادي — عرض بيانات محددة وتنفيذ عمليات محددة فقط',
        is_system: 1,
        permissions: [
            'content.view',
            'services.view',
            'requests.view.all',       // يعرض كل طلبات العملاء
            'requests.update.status',  // يحدّث حالة الطلب وملاحظاته
            'requests.create',
            'requests.view.own',
            'requests.update.own',
            'messages.view',           // يعرض الرسائل الواردة
            'files.upload',            // Task 10: يرفع ملفات
            'files.view.own',
            'files.delete.own',
            'files.view.all',          // Task 10: يعرض ملفات كل المستخدمين
            // Task 11: فريق العمل يتابع ويحدّث ويعيّن المشاريع، لكن الإنشاء والحذف للمدير
            'clients.view',
            'projects.view.all',
            'projects.update',
            'projects.update.status',
            'projects.assign',
        ],
    },
    {
        name: 'customer',
        description: 'عميل — يرسل طلباته ويتابعها فقط',
        is_system: 1,
        permissions: [
            'requests.create',
            'requests.view.own',
            'requests.update.own',
            'files.upload',            // Task 10
            'files.view.own',
            'files.delete.own',
            // Task 11: العميل يتابع فقط المشاريع المرتبطة بحسابه
            'projects.view.own',
        ],
    },
];

function seedDatabase() {
    const users = db.exec("SELECT COUNT(*) AS c FROM users");
    if (users[0].values[0][0] === 0) {
        db.run(`INSERT INTO users
            (username, password, full_name, email, role)
            VALUES (?, ?, ?, ?, ?)`,
            ['admin', hashPassword('admin123'), 'Nooraleeman Adel Al-shawesh', 'admin@nexatech.local', 'admin']);
        console.log('✓ Default admin user created (admin / admin123)');
    }

    seedRolesAndPermissions();

    const items = db.exec("SELECT COUNT(*) AS c FROM content_items");
    if (items[0].values[0][0] === 0) {
        const seed = [
            ['Web Development', 'service', 'Custom web applications built with modern frameworks and best practices.', 'images/web-dev.png', 'fa-code', 'published'],
            ['Mobile Apps', 'service', 'Native and cross-platform mobile applications for iOS and Android.', 'images/mobile-app.png', 'fa-mobile-alt', 'published'],
            ['Cloud Solutions', 'service', 'Scalable cloud infrastructure and migration services.', 'images/cloud-computing.png', 'fa-cloud', 'published'],
            ['Digital Marketing', 'service', 'Data-driven marketing strategies that increase visibility and conversions.', 'images/digital-marketing.png', 'fa-bullhorn', 'published'],
            ['UI/UX Design', 'service', 'Beautiful, intuitive interfaces that delight users.', 'images/marketing-3d.png', 'fa-paint-brush', 'published'],
            ['IT Consulting', 'service', 'Strategic technology consulting to align IT with business goals.', 'images/team-coding.png', 'fa-chart-pie', 'published'],
            ['E-Commerce Platform', 'project', 'Full-stack web application', 'images/web-dev.png', null, 'published'],
            ['Travel Booking App', 'project', 'Cross-platform mobile app', 'images/mobile-app.png', null, 'published'],
            ['Cloud Migration', 'project', 'Enterprise cloud solution', 'images/cloud-computing.png', null, 'published'],
            ['Marketing Dashboard', 'project', 'Analytics platform', 'images/digital-marketing.png', null, 'draft'],
        ];
        const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
        seed.forEach(row => stmt.run(row));
        stmt.free();
        console.log('✓ Content items seeded');
    }

    seedServices();
    seedRequests();
    seedClientsAndProjects(); // Task 11
}

// ==================== TASK 9: SEED ROLES & PERMISSIONS ====================
function seedRolesAndPermissions() {
    // 1) Permission catalog
    PERMISSIONS.forEach(p => {
        db.run(`INSERT INTO permissions (code, description, module)
                VALUES (?, ?, ?)
                ON CONFLICT(code) DO UPDATE SET description = excluded.description, module = excluded.module`,
            [p.code, p.description, p.module]);
    });

    // 2) Default roles + their permissions
    DEFAULT_ROLES.forEach(role => {
        db.run(`INSERT INTO roles (name, description, is_system)
                VALUES (?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET description = excluded.description`,
            [role.name, role.description, role.is_system]);
        const roleId = queryOne("SELECT id FROM roles WHERE name = ?", [role.name]).id;
        role.permissions.forEach(code => {
            const perm = queryOne("SELECT id FROM permissions WHERE code = ?", [code]);
            if (perm) {
                db.run("INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)", [roleId, perm.id]);
            }
        });
    });

    // 3) Demo employee account (Task 9 demo)
    const emp = queryOne("SELECT id FROM users WHERE username = 'employee1'");
    if (!emp) {
        db.run(`INSERT INTO users (username, password, full_name, email, phone, role)
                VALUES (?, ?, ?, ?, ?, 'employee')`,
            ['employee1', hashPassword('Emp12345'), 'موظف تجريبي', 'employee@nexatech.local', '0501111111']);
        console.log('✓ Demo employee created (employee1 / Emp12345)');
    }

    // 4) Any user whose role does not exist in roles table -> customer
    db.run(`UPDATE users SET role = 'customer'
            WHERE role NOT IN (SELECT name FROM roles)`);
}

function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

// ==================== TASK 7: SAMPLE REQUESTS SEED ====================
function seedRequests() {
    const c = db.exec("SELECT COUNT(*) AS c FROM requests");
    if (c[0].values[0][0] > 0) return;
    // Create a demo customer if none exists (so requests have a real owner)
    let custId = null;
    const anyCustomer = queryOne("SELECT id FROM users WHERE role = 'customer' LIMIT 1");
    if (!anyCustomer) {
        db.run(`INSERT INTO users (username, password, full_name, email, phone, role)
                VALUES (?, ?, ?, ?, ?, 'customer')`,
            ['demo_customer', hashPassword('Demo1234'), 'عميل تجريبي', 'demo@nexatech.local', '0500000000']);
        custId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
        console.log('✓ Demo customer created (demo_customer / Demo1234)');
    } else {
        custId = anyCustomer.id;
    }
    const svc = (n) => queryOne("SELECT id FROM services WHERE title = ?", [n])?.id || null;
    const seed = [
        [custId, svc('Web Development'), 'تطوير موقع شركة احترافي', 'نحتاج موقعًا تعريفيًا متكاملًا مع لوحة تحكم وربط بنظام الحجوزات.', 'high', 'in_progress', 'تم التواصل مع العميل وتحديد المتطلبات، جارٍ العمل على التصميم.'],
        [custId, svc('Mobile Apps'), 'تطبيق جوال لتوصيل الطلبات', 'تطبيق iOS وAndroid لشركة توصيل محلية مع تتبع مباشر للسائقين.', 'medium', 'pending', null],
        [custId, svc('Cloud Solutions'), 'نقل البنية التحتية للسحابة', 'ترحيل خوادمنا الحالية إلى AWS مع ضمان عدم توقف الخدمة.', 'medium', 'in_review', 'جارٍ تقييم البنية الحالية وإعداد خطة الترحيل.'],
        [custId, svc('Digital Marketing'), 'حملة تسويقية ربع سنوية', 'إدارة الحملات الإعلانية على منصات التواصل مع تقارير شهرية.', 'low', 'completed', 'تم إنجاز الحملة بنجاح ورفع التقرير النهائي.'],
        [custId, svc('UI/UX Design'), 'إعادة تصميم واجهة المتجر الإلكتروني', 'تحسين تجربة المستخدم ورفع معدل إتمام عمليات الشراء.', 'high', 'pending', null],
    ];
    const stmt = db.prepare(`INSERT INTO requests (user_id, service_id, title, description, priority, status, admin_notes)
                             VALUES (?, ?, ?, ?, ?, ?, ?)`);
    seed.forEach(r => stmt.run(r));
    stmt.free();
    console.log('✓ Sample requests seeded');
}


// ==================== TASK 11: CLIENTS & PROJECTS SEED ====================
function seedClientsAndProjects() {
    // Demo customer account used by the project platform
    if (!queryOne("SELECT id FROM users WHERE username = 'customer1'")) {
        db.run(`INSERT INTO users (username, password, full_name, email, phone, role)
                VALUES (?, ?, ?, ?, ?, 'customer')`,
            ['customer1', hashPassword('Demo1234'), 'عميل تجريبي', 'customer1@nexatech.local', '0502222222']);
        console.log('✓ Demo customer created (customer1 / Demo1234)');
    }

    if (db.exec("SELECT COUNT(*) AS c FROM clients")[0].values[0][0] === 0) {
        const customer = queryOne("SELECT id FROM users WHERE username = 'customer1'");
        const demo = queryOne("SELECT id FROM users WHERE username = 'demo_customer'");
        const rows = [
            ['شركة الأفق للتجارة', 'أحمد الخطيب', 'info@alofuq.example', '0501001001', customer?.id || null, 'عميل دائم — قطاع التجارة الإلكترونية', 'active'],
            ['مجموعة البيان المتحدة', 'سارة الحربي', 'info@bayan.example', '0502002002', demo?.id || null, 'عميل سحابي — يهتم بتحليلات الأداء', 'active'],
            ['مؤسسة النخبة الطبية', 'د. محمد العمري', 'contact@noblecare.example', '0503003003', null, 'عميل قطاع صحي', 'active'],
            ['شركة روافد التسويق', 'نورة القحطاني', 'hello@rawafed.example', '0504004004', null, 'عميل تسويق رقمي', 'active'],
        ];
        const stmt = db.prepare(`INSERT INTO clients (company, name, email, phone, user_id, notes, status)
                                 VALUES (?, ?, ?, ?, ?, ?, ?)`);
        rows.forEach(r => stmt.run(r));
        stmt.free();
        console.log('✓ Demo clients seeded');
    }

    if (db.exec("SELECT COUNT(*) AS c FROM projects")[0].values[0][0] > 0) return;
    const admin = queryOne("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    const employee = queryOne("SELECT id FROM users WHERE username = 'employee1'");
    const clientId = (company) => queryOne("SELECT id FROM clients WHERE company = ?", [company])?.id;
    const seeds = [
        ['تطوير منصة التجارة الإلكترونية', 'متجر إلكتروني متكامل مع بوابات دفع وتقارير مبيعات.', clientId('شركة الأفق للتجارة'), 'in_progress', 65, '2026-09-01', '2026-11-15'],
        ['تطبيق حجوزات العيادات', 'تطبيق جوال لحجز المواعيد وملفات المرضى وتذكيرات تلقائية.', clientId('مؤسسة النخبة الطبية'), 'in_progress', 40, '2026-09-10', '2026-12-01'],
        ['التحول السحابي ولوحة المؤشرات', 'ترحيل الخوادم إلى السحابة وبناء Dashboard تنفيذي.', clientId('مجموعة البيان المتحدة'), 'completed', 100, '2026-07-01', '2026-09-20'],
        ['إعادة تصميم الهوية الرقمية', 'تصميم UI/UX جديد مع دليل هوية رقمي كامل.', clientId('شركة روافد التسويق'), 'on_hold', 35, '2026-08-15', '2026-10-30'],
        ['بوابة خدمات العملاء', 'بوابة دعم وتذاكر مرتبطة بنظام CRM.', clientId('شركة الأفق للتجارة'), 'not_started', 0, '2026-10-10', '2026-12-31'],
    ];
    const stmt = db.prepare(`INSERT INTO projects (name, description, client_id, status, progress, start_date, due_date, created_by)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    const inserted = [];
    seeds.forEach(r => {
        stmt.run([r[0], r[1], r[2], r[3], r[4], r[5], r[6], admin?.id || 1]);
        inserted.push(db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0]);
    });
    stmt.free();
    if (employee) {
        setProjectMembers(inserted[0], [employee.id]);
        setProjectMembers(inserted[1], [employee.id]);
    }
    console.log('✓ Demo projects seeded with team assignments');
}

// ==================== TASK 6: SERVICES SEED ====================
function seedServices() {
    const c = db.exec("SELECT COUNT(*) AS c FROM services");
    if (c[0].values[0][0] > 0) return;
    const seed = [
        ['Web Development', 'Custom web applications built with modern frameworks and best practices. From simple landing pages to complex enterprise solutions.', 'fa-code', 'images/web-dev.png', 'Responsive Design|SEO Optimized|High Performance'],
        ['Mobile Apps', 'Native and cross-platform mobile applications for iOS and Android. Engaging user experiences that drive retention and growth.', 'fa-mobile-alt', 'images/mobile-app.png', 'iOS & Android|Cross-Platform|UI/UX Design'],
        ['Cloud Solutions', 'Scalable cloud infrastructure and migration services. Optimize costs and improve reliability with our cloud expertise.', 'fa-cloud', 'images/cloud-computing.png', 'AWS & Azure|Cloud Migration|DevOps'],
        ['Digital Marketing', 'Data-driven marketing strategies that increase visibility and conversions. SEO, PPC, social media, and content marketing.', 'fa-bullhorn', 'images/digital-marketing.png', 'SEO & SEM|Social Media|Analytics'],
        ['UI/UX Design', 'Beautiful, intuitive interfaces that delight users. User-centered design process from research to prototyping.', 'fa-paint-brush', 'images/marketing-3d.png', 'User Research|Prototyping|Design Systems'],
        ['IT Consulting', 'Strategic technology consulting to align IT with business goals. Digital transformation and process optimization.', 'fa-chart-pie', 'images/team-coding.png', 'Strategy|Architecture|Optimization'],
    ];
    const stmt = db.prepare("INSERT INTO services (title, description, icon, image, features) VALUES (?, ?, ?, ?, ?)");
    seed.forEach(r => stmt.run(r));
    stmt.free();
    console.log('✓ Services seeded');
}

function queryAll(sql, params = []) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
}

function queryOne(sql, params = []) {
    return queryAll(sql, params)[0] || null;
}

function safeUser(user) {
    if (!user) return null;
    return {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        created_at: user.created_at,
        updated_at: user.user_updated_at || user.updated_at
    };
}

// ==================== MIDDLEWARE ====================
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

function requireAuth(req, res, next) {
    const token = req.headers['authorization']?.replace('Bearer ', '');
    const sessionUser = token && sessions[token];

    if (!sessionUser) {
        return res.status(401).json({ success: false, message: 'غير مصرح - يرجى تسجيل الدخول أولاً' });
    }

    const freshUser = queryOne("SELECT * FROM users WHERE id = ?", [sessionUser.id]);
    if (!freshUser) {
        delete sessions[token];
        return res.status(401).json({ success: false, message: 'المستخدم غير موجود أو انتهت الجلسة' });
    }

    req.token = token;
    req.user = safeUser(freshUser);
    next();
}

// ==================== TASK 9: RBAC CORE ====================
// Resolve the permission codes granted to a role. Cached in memory and
// invalidated whenever roles/permissions change.
function getRolePermissions(roleName) {
    if (!roleName) return [];
    if (permCache[roleName]) return permCache[roleName];
    const rows = queryAll(
        `SELECT p.code FROM permissions p
         JOIN role_permissions rp ON rp.permission_id = p.id
         JOIN roles r ON r.id = rp.role_id
         WHERE r.name = ?`, [roleName]);
    permCache[roleName] = rows.map(r => r.code);
    return permCache[roleName];
}

function invalidatePermCache() {
    Object.keys(permCache).forEach(k => delete permCache[k]);
}

function hasPermission(user, code) {
    return getRolePermissions(user?.role).includes(code);
}

// Backend enforcement: reject the request with 403 unless the user's role
// holds the required permission. Checked on the SERVER before any protected
// operation touches the database.
function requirePermission(...codes) {
    return (req, res, next) => {
        const owned = getRolePermissions(req.user?.role);
        const ok = codes.some(c => owned.includes(c));
        if (!ok) {
            return res.status(403).json({
                success: false,
                message: 'ممنوع: دورك الحالي لا يملك الصلاحية المطلوبة لتنفيذ هذه العملية',
                required: codes,
                yourRole: req.user?.role,
                yourPermissions: owned
            });
        }
        next();
    };
}

// Backward-compatible helper kept from previous tasks: admin-only guard,
// now enforced through the roles table (admin holds roles.manage).
function requireAdmin(req, res, next) {
    if (req.user?.role === 'admin') return next();
    return res.status(403).json({ success: false, message: 'هذه العملية متاحة للمدير فقط' });
}

// Staff = admin or employee (company side)
function requireStaff(req, res, next) {
    if (['admin', 'employee'].includes(req.user?.role)) return next();
    return res.status(403).json({ success: false, message: 'هذه العملية متاحة لفريق الشركة فقط' });
}

function roleWithPermissions(roleRow) {
    return {
        id: roleRow.id,
        name: roleRow.name,
        description: roleRow.description,
        is_system: roleRow.is_system,
        created_at: roleRow.created_at,
        updated_at: roleRow.updated_at,
        permissions: getRolePermissions(roleRow.name),
        users_count: queryOne("SELECT COUNT(*) AS c FROM users WHERE role = ?", [roleRow.name])?.c || 0
    };
}

// Task 10: uploaded files are served ONLY through the authenticated download endpoint
app.use('/uploads', (req, res) => res.status(403).json({ success: false, message: 'الوصول للملفات عبر endpoint التحميل المصادق عليه فقط' }));
app.use(express.static(ROOT));

// ==================== AUTH API ====================
app.post('/api/register', (req, res) => {
    const fullName = (req.body.fullName || '').trim();
    const username = (req.body.username || '').trim();
    const email = (req.body.email || '').trim();
    const password = req.body.password || '';
    const confirmPassword = req.body.confirmPassword || '';

    const errors = [];
    if (fullName.length < 3) errors.push('الاسم الكامل مطلوب ويجب ألا يقل عن 3 أحرف');
    if (!/^[a-zA-Z0-9_.-]{3,30}$/.test(username)) errors.push('اسم المستخدم يجب أن يكون إنجليزيًا من 3 إلى 30 حرفًا');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('البريد الإلكتروني غير صحيح');
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) errors.push('كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي حرفًا ورقمًا');
    if (password !== confirmPassword) errors.push('تأكيد كلمة المرور غير مطابق');

    if (errors.length) {
        return res.status(400).json({ success: false, message: 'يرجى تصحيح الأخطاء التالية', errors });
    }

    if (queryOne("SELECT id FROM users WHERE LOWER(username) = LOWER(?)", [username])) {
        errors.push('اسم المستخدم مستخدم مسبقًا');
    }
    if (queryOne("SELECT id FROM users WHERE LOWER(COALESCE(email,'')) = LOWER(?)", [email])) {
        errors.push('البريد الإلكتروني مستخدم مسبقًا');
    }
    if (errors.length) {
        return res.status(400).json({ success: false, message: 'يرجى تصحيح الأخطاء التالية', errors });
    }

    // New self-registered accounts are always customers (Task 9: role assignment is admin-only)
    db.run(`INSERT INTO users (username, password, full_name, email, role)
            VALUES (?, ?, ?, ?, 'customer')`,
        [username, hashPassword(password), fullName, email]);
    saveDatabase();

    const user = queryOne("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", [username]);
    const token = crypto.randomBytes(24).toString('hex');
    sessions[token] = safeUser(user);

    res.status(201).json({
        success: true, message: 'تم إنشاء الحساب بنجاح', token,
        user: sessions[token],
        permissions: getRolePermissions(user.role) // Task 9
    });
});

app.post('/api/login', (req, res) => {
    const usernameOrEmail = (req.body.username || req.body.email || '').trim();
    const password = req.body.password || '';

    if (!usernameOrEmail || !password) {
        return res.status(400).json({ success: false, message: 'يرجى إدخال اسم المستخدم أو البريد الإلكتروني وكلمة المرور' });
    }

    const user = queryOne(`SELECT * FROM users
        WHERE LOWER(username) = LOWER(?) OR LOWER(COALESCE(email, '')) = LOWER(?)`,
        [usernameOrEmail, usernameOrEmail]);

    if (!user || user.password !== hashPassword(password)) {
        return res.status(401).json({ success: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    const token = crypto.randomBytes(24).toString('hex');
    sessions[token] = safeUser(user);
    res.json({
        success: true, token,
        user: sessions[token],
        permissions: getRolePermissions(user.role) // Task 9
    });
});

app.post('/api/logout', requireAuth, (req, res) => {
    delete sessions[req.token];
    res.json({ success: true, message: 'تم تسجيل الخروج بنجاح' });
});

app.get('/api/me', requireAuth, (req, res) => {
    res.json({
        success: true,
        user: req.user,
        permissions: getRolePermissions(req.user.role) // Task 9
    });
});

// ==================== TASK 9: CURRENT USER PERMISSIONS ====================
// Tells the frontend exactly what this user may do so the UI can adapt.
app.get('/api/me/permissions', requireAuth, (req, res) => {
    const roleRow = queryOne("SELECT * FROM roles WHERE name = ?", [req.user.role]);
    res.json({
        success: true,
        user: req.user,
        role: roleRow ? { name: roleRow.name, description: roleRow.description, is_system: roleRow.is_system } : null,
        permissions: getRolePermissions(req.user.role)
    });
});

app.put('/api/profile', requireAuth, (req, res) => {
    const fullName = (req.body.fullName || '').trim();
    const email = (req.body.email || '').trim();
    const phone = (req.body.phone || '').trim();

    const errors = [];
    if (fullName.length < 3) errors.push('الاسم الكامل مطلوب');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('البريد الإلكتروني غير صحيح');
    if (phone.length > 20) errors.push('رقم الهاتف طويل جدًا');
    if (errors.length) return res.status(400).json({ success: false, message: 'بيانات غير صحيحة', errors });

    const existingEmail = queryOne(`SELECT id FROM users
        WHERE LOWER(COALESCE(email,'')) = LOWER(?) AND id != ?`, [email, req.user.id]);
    if (existingEmail) {
        return res.status(409).json({ success: false, message: 'البريد الإلكتروني مستخدم بواسطة حساب آخر' });
    }

    db.run(`UPDATE users
            SET full_name = ?, email = ?, phone = ?, updated_at = datetime('now')
            WHERE id = ?`, [fullName, email, phone, req.user.id]);
    saveDatabase();

    const user = safeUser(queryOne("SELECT * FROM users WHERE id = ?", [req.user.id]));
    sessions[req.token] = user;

    res.json({ success: true, message: 'تم تحديث بيانات الحساب بنجاح', user });
});

app.post('/api/password', requireAuth, (req, res) => {
    const currentPassword = req.body.currentPassword || '';
    const newPassword = req.body.newPassword || '';

    const user = queryOne("SELECT * FROM users WHERE id = ?", [req.user.id]);
    if (!user || user.password !== hashPassword(currentPassword)) {
        return res.status(401).json({ success: false, message: 'كلمة المرور الحالية غير صحيحة' });
    }
    if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return res.status(400).json({ success: false, message: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل وتحتوي حرفًا ورقمًا' });
    }

    db.run(`UPDATE users SET password = ?, updated_at = datetime('now') WHERE id = ?`,
        [hashPassword(newPassword), req.user.id]);
    saveDatabase();

    res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
});

// ==================== TASK 9: ROLE & PERMISSION MANAGEMENT API ====================
// All endpoints below require the admin's roles.manage / users.manage permissions.

// Permission catalog (for building role editors in the UI)
app.get('/api/permissions', requireAuth, requirePermission('roles.manage'), (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM permissions ORDER BY module, id") });
});

// List all roles with their permissions + user counts
app.get('/api/roles', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const roles = queryAll("SELECT * FROM roles ORDER BY is_system DESC, id ASC").map(roleWithPermissions);
    res.json({ success: true, data: roles });
});

// Create a new custom role with a permission set
app.post('/api/roles', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const name = (req.body.name || '').trim().toLowerCase();
    const description = (req.body.description || '').trim();
    const permissions = Array.isArray(req.body.permissions) ? req.body.permissions : [];

    if (!/^[a-z][a-z0-9_.-]{2,29}$/.test(name)) {
        return res.status(400).json({ success: false, message: 'اسم الدور يجب أن يكون إنجليزيًا صغيرًا من 3 إلى 30 حرفًا ويبدأ بحرف' });
    }
    if (queryOne("SELECT id FROM roles WHERE name = ?", [name])) {
        return res.status(409).json({ success: false, message: 'يوجد دور بهذا الاسم مسبقًا' });
    }
    const validCodes = new Set(queryAll("SELECT code FROM permissions").map(p => p.code));
    const bad = permissions.filter(p => !validCodes.has(p));
    if (bad.length) {
        return res.status(400).json({ success: false, message: 'صلاحيات غير معروفة', invalid: bad });
    }

    db.run("INSERT INTO roles (name, description, is_system) VALUES (?, ?, 0)", [name, description]);
    const roleId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    permissions.forEach(code => {
        const perm = queryOne("SELECT id FROM permissions WHERE code = ?", [code]);
        db.run("INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)", [roleId, perm.id]);
    });
    saveDatabase();
    invalidatePermCache();

    res.status(201).json({ success: true, message: 'تم إنشاء الدور بنجاح', data: roleWithPermissions(queryOne("SELECT * FROM roles WHERE id = ?", [roleId])) });
});

// Update a role: description and/or permission set.
// The system 'admin' role's permissions are locked so the platform can never be locked out.
app.put('/api/roles/:name', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const role = queryOne("SELECT * FROM roles WHERE name = ?", [req.params.name]);
    if (!role) return res.status(404).json({ success: false, message: 'الدور غير موجود' });

    const description = (req.body.description ?? role.description);
    db.run("UPDATE roles SET description = ?, updated_at = datetime('now') WHERE id = ?", [description, role.id]);

    if (Array.isArray(req.body.permissions)) {
        if (role.name === 'admin') {
            return res.status(400).json({ success: false, message: 'لا يمكن تعديل صلاحيات دور المدير (دور نظام محمي)' });
        }
        const validCodes = new Set(queryAll("SELECT code FROM permissions").map(p => p.code));
        const bad = req.body.permissions.filter(p => !validCodes.has(p));
        if (bad.length) return res.status(400).json({ success: false, message: 'صلاحيات غير معروفة', invalid: bad });

        db.run("DELETE FROM role_permissions WHERE role_id = ?", [role.id]);
        req.body.permissions.forEach(code => {
            const perm = queryOne("SELECT id FROM permissions WHERE code = ?", [code]);
            db.run("INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)", [role.id, perm.id]);
        });
    }
    saveDatabase();
    invalidatePermCache();

    res.json({ success: true, message: 'تم تحديث الدور بنجاح', data: roleWithPermissions(queryOne("SELECT * FROM roles WHERE id = ?", [role.id])) });
});

// Delete a custom role (system roles and roles still in use are protected)
app.delete('/api/roles/:name', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const role = queryOne("SELECT * FROM roles WHERE name = ?", [req.params.name]);
    if (!role) return res.status(404).json({ success: false, message: 'الدور غير موجود' });
    if (role.is_system) return res.status(400).json({ success: false, message: 'لا يمكن حذف أدوار النظام الافتراضية' });

    const usersCount = queryOne("SELECT COUNT(*) AS c FROM users WHERE role = ?", [role.name])?.c || 0;
    if (usersCount > 0) return res.status(400).json({ success: false, message: `لا يمكن حذف الدور — يستخدمه ${usersCount} مستخدم. عيّن لهم دورًا آخر أولاً.` });

    db.run("DELETE FROM roles WHERE id = ?", [role.id]); // role_permissions cascade
    saveDatabase();
    invalidatePermCache();
    res.json({ success: true, message: 'تم حذف الدور بنجاح' });
});

// List users (with their roles) — admin/users.view
app.get('/api/users', requireAuth, requirePermission('users.view'), (req, res) => {
    const users = queryAll(`SELECT id, username, full_name, email, phone, role, created_at, updated_at
                            FROM users ORDER BY id ASC`).map(u => ({
        ...u,
        permissions: getRolePermissions(u.role)
    }));
    const roles = queryAll("SELECT name, description, is_system FROM roles ORDER BY is_system DESC, id ASC");
    res.json({ success: true, data: users, roles });
});

// Assign a role to a user — admin/users.manage
// Cannot: change your own role away from admin, demote the last admin, or assign unknown roles.
app.put('/api/users/:id/role', requireAuth, requirePermission('users.manage'), (req, res) => {
    const target = queryOne("SELECT * FROM users WHERE id = ?", [req.params.id]);
    if (!target) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });

    const roleName = (req.body.role || '').trim().toLowerCase();
    if (!queryOne("SELECT id FROM roles WHERE name = ?", [roleName])) {
        return res.status(400).json({ success: false, message: 'الدور المطلوب غير موجود' });
    }
    if (target.id === req.user.id && roleName !== 'admin') {
        return res.status(400).json({ success: false, message: 'لا يمكنك إزالة دور المدير عن حسابك الخاص' });
    }
    if (target.role === 'admin' && roleName !== 'admin') {
        const admins = queryOne("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'")?.c || 0;
        if (admins <= 1) return res.status(400).json({ success: false, message: 'لا يمكن تغيير دور آخر مدير في النظام' });
    }

    db.run("UPDATE users SET role = ?, updated_at = datetime('now') WHERE id = ?", [roleName, target.id]);
    saveDatabase();

    // Refresh any active sessions of that user
    Object.entries(sessions).forEach(([tok, u]) => {
        if (u.id === target.id) sessions[tok] = safeUser(queryOne("SELECT * FROM users WHERE id = ?", [target.id]));
    });

    res.json({ success: true, message: `تم تعيين دور "${roleName}" للمستخدم ${target.username} بنجاح` });
});

// ==================== CUSTOMER DASHBOARD API ====================
app.get('/api/dashboard', requireAuth, (req, res) => {
    const publishedContent = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'published'")?.c || 0;
    let messagesCount = 0;
    let recentMessages = [];

    if (req.user.email) {
        messagesCount = queryOne("SELECT COUNT(*) AS c FROM messages WHERE LOWER(email) = LOWER(?)", [req.user.email])?.c || 0;
        recentMessages = queryAll(`SELECT id, name, email, subject, message, created_at
            FROM messages WHERE LOWER(email) = LOWER(?) ORDER BY id DESC LIMIT 5`, [req.user.email]);
    }

    const requestsCount = queryOne("SELECT COUNT(*) AS c FROM requests WHERE user_id = ?", [req.user.id])?.c || 0;
    const recentRequests = queryAll(`SELECT id, title, status, priority, created_at
        FROM requests WHERE user_id = ? ORDER BY id DESC LIMIT 5`, [req.user.id]);

    // Task 11: project counters are calculated only from projects this user may access
    const accessibleProjects = accessibleProjectsForUser(req.user);
    const projectsCount = accessibleProjects.length;
    const inProgressProjects = accessibleProjects.filter(p => p.status === 'in_progress').length;
    const completedProjects = accessibleProjects.filter(p => p.status === 'completed').length;
    const recentProjects = accessibleProjects.slice(0, 5);

    res.json({
        success: true,
        user: req.user,
        permissions: getRolePermissions(req.user.role), // Task 9
        stats: { publishedContent, messagesCount, requestsCount, projectsCount, inProgressProjects, completedProjects },
        recentMessages,
        recentRequests,
        recentProjects
    });
});

// ==================== CONTENT CRUD API ====================
app.get('/api/content', (req, res) => {
    const { category, status, search } = req.query;
    let sql = "SELECT * FROM content_items WHERE 1=1";
    const params = [];
    if (category) { sql += " AND category = ?"; params.push(category); }
    if (status) { sql += " AND status = ?"; params.push(status); }
    if (search) { sql += " AND (title LIKE ? OR description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }
    sql += " ORDER BY id DESC";
    res.json({ success: true, data: queryAll(sql, params) });
});

app.get('/api/content/:id', (req, res) => {
    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    if (!item) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    res.json({ success: true, data: item });
});

// Task 9: write operations now checked with the content.manage permission
app.post('/api/content', requireAuth, requirePermission('content.manage'), (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    if (!title || !category) return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });

    const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
    stmt.run([title, category, description ?? '', image ?? 'images/web-dev.png', icon ?? null, status ?? 'published']);
    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    stmt.free();
    saveDatabase();

    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [newId]);
    res.status(201).json({ success: true, message: 'تمت إضافة العنصر بنجاح', data: item });
});

app.put('/api/content/:id', requireAuth, requirePermission('content.manage'), (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    if (!title || !category) return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });

    db.run(`UPDATE content_items SET title = ?, category = ?, description = ?, image = ?, icon = ?, status = ?, updated_at = datetime('now')
            WHERE id = ?`, [title, category, description || '', image || '', icon || null, status || 'published', req.params.id]);
    saveDatabase();

    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: 'تم تحديث العنصر بنجاح', data: item });
});

app.delete('/api/content/:id', requireAuth, requirePermission('content.manage'), (req, res) => {
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    db.run("DELETE FROM content_items WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف العنصر بنجاح' });
});

// ==================== SERVICES API (TASK 6) ====================
// Public: active services only (used by the public website)
app.get('/api/services', (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM services WHERE status = 'active' ORDER BY id ASC") });
});

// All services (active + inactive). NOTE: /all must be registered BEFORE /:id
// Task 9: company-side view — admin (services.manage) or employee
app.get('/api/services/all', requireAuth, requireStaff, (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM services ORDER BY id DESC") });
});

app.get('/api/services/:id', requireAuth, requireStaff, (req, res) => {
    const s = queryOne("SELECT * FROM services WHERE id = ?", [req.params.id]);
    if (!s) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    res.json({ success: true, data: s });
});

// Task 9: management operations require the services.manage permission
app.post('/api/services', requireAuth, requirePermission('services.manage'), (req, res) => {
    const { title, description, icon, image, features, status } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ success: false, message: 'اسم الخدمة مطلوب' });
    const stmt = db.prepare("INSERT INTO services (title, description, icon, image, features, status) VALUES (?, ?, ?, ?, ?, ?)");
    stmt.run([title.trim(), description || '', icon || 'fa-code', image || 'images/web-dev.png', features || '', status === 'inactive' ? 'inactive' : 'active']);
    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    stmt.free();
    saveDatabase();
    res.status(201).json({ success: true, message: 'تمت إضافة الخدمة بنجاح', data: queryOne("SELECT * FROM services WHERE id = ?", [newId]) });
});

app.put('/api/services/:id', requireAuth, requirePermission('services.manage'), (req, res) => {
    const existing = queryOne("SELECT id FROM services WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    const { title, description, icon, image, features, status } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ success: false, message: 'اسم الخدمة مطلوب' });
    db.run(`UPDATE services SET title=?, description=?, icon=?, image=?, features=?, status=?, updated_at=datetime('now') WHERE id=?`,
        [title.trim(), description || '', icon || 'fa-code', image || '', features || '', status === 'inactive' ? 'inactive' : 'active', req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم تحديث الخدمة بنجاح', data: queryOne("SELECT * FROM services WHERE id = ?", [req.params.id]) });
});

app.delete('/api/services/:id', requireAuth, requirePermission('services.manage'), (req, res) => {
    const existing = queryOne("SELECT id FROM services WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    db.run("DELETE FROM services WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الخدمة بنجاح' });
});

// ==================== STATS API ====================
app.get('/api/stats', requireAuth, requireStaff, (req, res) => {
    const total = queryOne("SELECT COUNT(*) AS c FROM content_items")['c'];
    const published = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'published'")['c'];
    const drafts = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'draft'")['c'];
    const byCategory = queryAll("SELECT category, COUNT(*) AS count FROM content_items GROUP BY category");
    res.json({ success: true, data: { total, published, drafts, byCategory } });
});

// ==================== CONTACT MESSAGES API ====================
app.post('/api/messages', (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    if (!name || !email || !message) {
        return res.status(400).json({ success: false, message: 'الاسم والبريد والرسالة مطلوبة' });
    }
    db.run("INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)",
        [name, email, phone || '', subject || '', message]);
    saveDatabase();
    res.status(201).json({ success: true, message: 'تم إرسال رسالتك بنجاح' });
});

// Task 9: viewing inbox requires messages.view (admin + employee)
app.get('/api/messages', requireAuth, requirePermission('messages.view'), (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM messages ORDER BY id DESC") });
});

// Task 9: deleting messages requires messages.delete (admin only by default)
app.delete('/api/messages/:id', requireAuth, requirePermission('messages.delete'), (req, res) => {
    db.run("DELETE FROM messages WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الرسالة' });
});

// ==================== TASK 7: CUSTOMER REQUEST MANAGEMENT API ====================
// Status workflow: pending -> in_review -> in_progress -> completed | cancelled
const REQUEST_STATUSES = ['pending', 'in_review', 'in_progress', 'completed', 'cancelled'];
const PRIORITIES = ['low', 'medium', 'high'];

function requestWithCustomer(r) {
    return {
        ...r,
        customer_name: r.customer_name || null,
        customer_email: r.customer_email || null,
        service_title: r.service_title || null
    };
}

// Customer-side: submit a new service request (saved to DB with initial status 'pending')
app.post('/api/requests', requireAuth, requirePermission('requests.create'), (req, res) => {
    const title = (req.body.title || '').trim();
    const description = (req.body.description || '').trim();
    const serviceId = req.body.serviceId ? parseInt(req.body.serviceId) : null;
    const priority = PRIORITIES.includes(req.body.priority) ? req.body.priority : 'medium';

    if (!title || title.length < 5) {
        return res.status(400).json({ success: false, message: 'عنوان الطلب مطلوب (5 أحرف على الأقل)' });
    }
    if (!description || description.length < 10) {
        return res.status(400).json({ success: false, message: 'وصف الطلب مطلوب (10 أحرف على الأقل)' });
    }
    if (serviceId) {
        const svc = queryOne("SELECT id FROM services WHERE id = ? AND status = 'active'", [serviceId]);
        if (!svc) return res.status(400).json({ success: false, message: 'الخدمة المحددة غير متوفرة' });
    }

    db.run(`INSERT INTO requests (user_id, service_id, title, description, priority, status)
            VALUES (?, ?, ?, ?, ?, 'pending')`,
        [req.user.id, serviceId, title, description, priority]);
    saveDatabase();

    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    const item = queryOne(`SELECT r.*, s.title AS service_title FROM requests r
                           LEFT JOIN services s ON s.id = r.service_id WHERE r.id = ?`, [newId]);
    res.status(201).json({ success: true, message: 'تم إرسال طلبك بنجاح وسيتم مراجعته من فريق الشركة', data: item });
});

// Customer-side: my own requests
app.get('/api/requests/mine', requireAuth, requirePermission('requests.view.own'), (req, res) => {
    const rows = queryAll(`SELECT r.*, s.title AS service_title FROM requests r
                           LEFT JOIN services s ON s.id = r.service_id
                           WHERE r.user_id = ? ORDER BY r.id DESC`, [req.user.id]);
    res.json({ success: true, data: rows });
});

// ==================== TASK 8: SEARCH & FILTERING (BACKEND-DRIVEN, NO HARDCODED DATA) ====================
// Company-side: list ALL requests with search + multi-criteria filters.
// Task 9: requires the requests.view.all permission (admin + employee).
app.get('/api/requests', requireAuth, requirePermission('requests.view.all'), (req, res) => {
    const { search, status, priority, service_id, date_from, date_to, sort } = req.query;

    let sql = `SELECT r.*, u.full_name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
                      s.title AS service_title
               FROM requests r
               JOIN users u ON u.id = r.user_id
               LEFT JOIN services s ON s.id = r.service_id
               WHERE 1=1`;
    const params = [];

    // Free-text search: matches request title/description OR customer name/email
    if (search && search.trim()) {
        sql += ` AND (r.title LIKE ? OR r.description LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
        const q = `%${search.trim()}%`;
        params.push(q, q, q, q);
    }
    // Filters (multi-criteria, combinable)
    if (status && REQUEST_STATUSES.includes(status)) { sql += " AND r.status = ?"; params.push(status); }
    if (priority && PRIORITIES.includes(priority)) { sql += " AND r.priority = ?"; params.push(priority); }
    if (service_id && !isNaN(parseInt(service_id))) { sql += " AND r.service_id = ?"; params.push(parseInt(service_id)); }
    if (date_from) { sql += " AND date(r.created_at) >= date(?)"; params.push(date_from); }
    if (date_to) { sql += " AND date(r.created_at) <= date(?)"; params.push(date_to); }

    // Sorting (white-listed)
    const sortMap = {
        newest: 'r.id DESC', oldest: 'r.id ASC',
        priority: `CASE r.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, r.id DESC`,
        status: 'r.status ASC, r.id DESC'
    };
    sql += " ORDER BY " + (sortMap[sort] || sortMap.newest);

    const data = queryAll(sql, params).map(requestWithCustomer);

    // Filter-aware summary stats (so numbers always match the visible results)
    const counts = {};
    REQUEST_STATUSES.forEach(s => counts[s] = 0);
    queryAll(`SELECT r.status, COUNT(*) AS c FROM requests r JOIN users u ON u.id = r.user_id WHERE 1=1` +
        buildWhere({ search, status, priority, service_id, date_from, date_to }).clause +
        " GROUP BY r.status",
        buildWhere({ search, status, priority, service_id, date_from, date_to }).params)
        .forEach(row => counts[row.status] = row.c);

    res.json({ success: true, data, total: data.length, counts });
});

function buildWhere({ search, status, priority, service_id, date_from, date_to }) {
    let clause = ''; const params = [];
    if (search && search.trim()) {
        clause += ` AND (r.title LIKE ? OR r.description LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
        const q = `%${search.trim()}%`;
        params.push(q, q, q, q);
    }
    if (status && REQUEST_STATUSES.includes(status)) { clause += " AND r.status = ?"; params.push(status); }
    if (priority && PRIORITIES.includes(priority)) { clause += " AND r.priority = ?"; params.push(priority); }
    if (service_id && !isNaN(parseInt(service_id))) { clause += " AND r.service_id = ?"; params.push(parseInt(service_id)); }
    if (date_from) { clause += " AND date(r.created_at) >= date(?)"; params.push(date_from); }
    if (date_to) { clause += " AND date(r.created_at) <= date(?)"; params.push(date_to); }
    return { clause, params };
}

// Company-side: single request detail (admin/employee OR the owning customer)
app.get('/api/requests/:id', requireAuth, (req, res) => {
    const r = queryOne(`SELECT r.*, u.full_name AS customer_name, u.email AS customer_email,
                               u.phone AS customer_phone, s.title AS service_title
                        FROM requests r
                        JOIN users u ON u.id = r.user_id
                        LEFT JOIN services s ON s.id = r.service_id
                        WHERE r.id = ?`, [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (!hasPermission(req.user, 'requests.view.all') && r.user_id !== req.user.id) {
        return res.status(403).json({ success: false, message: 'لا يمكنك عرض طلبات عملاء آخرين' });
    }
    res.json({ success: true, data: r });
});

// Customer-side: edit/cancel own request (only while pending)
app.put('/api/requests/:id', requireAuth, (req, res) => {
    const r = queryOne("SELECT * FROM requests WHERE id = ?", [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (r.user_id !== req.user.id) return res.status(403).json({ success: false, message: 'لا يمكنك تعديل طلبات الآخرين' });

    const title = (req.body.title || '').trim();
    const description = (req.body.description || '').trim();
    const priority = PRIORITIES.includes(req.body.priority) ? req.body.priority : r.priority;
    const status = req.body.status;

    // Customer can cancel their own pending/in_review request
    if (status === 'cancelled') {
        if (!['pending', 'in_review'].includes(r.status)) {
            return res.status(400).json({ success: false, message: 'لا يمكن إلغاء طلب بدأت معالجته' });
        }
        db.run(`UPDATE requests SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`, [r.id]);
        saveDatabase();
        return res.json({ success: true, message: 'تم إلغاء الطلب', data: queryOne("SELECT * FROM requests WHERE id = ?", [r.id]) });
    }

    if (r.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'لا يمكن تعديل الطلب بعد بدء معالجته' });
    }
    if (title.length < 5 || description.length < 10) {
        return res.status(400).json({ success: false, message: 'عنوان الطلب (5+) ووصفه (10+) مطلوبان' });
    }
    db.run(`UPDATE requests SET title = ?, description = ?, priority = ?, updated_at = datetime('now') WHERE id = ?`,
        [title, description, priority, r.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم تحديث الطلب بنجاح', data: queryOne("SELECT * FROM requests WHERE id = ?", [r.id]) });
});

// Company-side: update request status + admin notes (full status workflow)
// Task 9: requires requests.update.status (admin + employee — regular employee CAN process requests)
app.put('/api/requests/:id/status', requireAuth, requirePermission('requests.update.status'), (req, res) => {
    const r = queryOne("SELECT * FROM requests WHERE id = ?", [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });

    const status = req.body.status;
    if (!REQUEST_STATUSES.includes(status)) {
        return res.status(400).json({ success: false, message: 'حالة غير صحيحة', valid: REQUEST_STATUSES });
    }
    const notes = (req.body.adminNotes || '').trim();

    db.run(`UPDATE requests SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?`,
        [status, notes, r.id]);
    saveDatabase();

    const updated = queryOne(`SELECT r.*, u.full_name AS customer_name, u.email AS customer_email,
                                     s.title AS service_title
                              FROM requests r JOIN users u ON u.id = r.user_id
                              LEFT JOIN services s ON s.id = r.service_id WHERE r.id = ?`, [r.id]);
    res.json({ success: true, message: 'تم تحديث حالة الطلب بنجاح', data: updated });
});



// ==================== TASK 11: CLIENT PROJECT MANAGEMENT API ====================
const PROJECT_STATUSES = ['not_started', 'in_progress', 'completed', 'on_hold'];

function projectBaseQuery() {
    return `SELECT p.*, c.name AS client_name, c.company AS client_company, c.email AS client_email,
                   c.user_id AS client_user_id, u.full_name AS creator_name
            FROM projects p
            JOIN clients c ON c.id = p.client_id
            LEFT JOIN users u ON u.id = p.created_by`;
}

function canAccessProject(user, project) {
    if (!project) return false;
    if (hasPermission(user, 'projects.view.all')) return true;
    if (project.created_by === user.id || project.client_user_id === user.id) return true;
    return !!queryOne("SELECT project_id FROM project_members WHERE project_id = ? AND user_id = ?",
        [project.id, user.id]);
}

function accessibleProjectsForUser(user, filters = {}) {
    let rows = queryAll(projectBaseQuery() + " ORDER BY p.updated_at DESC, p.id DESC");
    rows = rows.filter(p => canAccessProject(user, p));
    if (filters.search) {
        const q = String(filters.search).toLowerCase();
        rows = rows.filter(p => [p.name, p.description, p.client_name, p.client_company]
            .some(v => String(v || '').toLowerCase().includes(q)));
    }
    if (filters.status && PROJECT_STATUSES.includes(filters.status)) rows = rows.filter(p => p.status === filters.status);
    if (filters.client_id) rows = rows.filter(p => Number(p.client_id) === Number(filters.client_id));
    return rows;
}

function projectWithDetails(p) {
    const members = queryAll(`SELECT u.id, u.full_name, u.username, u.role, pm.assigned_at
                              FROM project_members pm JOIN users u ON u.id = pm.user_id
                              WHERE pm.project_id = ? ORDER BY u.full_name`, [p.id]);
    return { ...p, members, assigned_names: members.map(m => m.full_name) };
}

function setProjectMembers(projectId, memberIds) {
    db.run("DELETE FROM project_members WHERE project_id = ?", [projectId]);
    const ids = [...new Set((Array.isArray(memberIds) ? memberIds : []).map(Number).filter(Boolean))];
    ids.forEach(id => {
        const member = queryOne("SELECT id FROM users WHERE id = ? AND role IN ('admin','employee')", [id]);
        if (member) db.run("INSERT OR IGNORE INTO project_members (project_id, user_id) VALUES (?, ?)", [projectId, id]);
    });
}

function validateProjectPayload(body) {
    const errors = [];
    const name = (body.name || '').trim();
    const description = (body.description || '').trim();
    const clientId = parseInt(body.client_id, 10);
    const status = PROJECT_STATUSES.includes(body.status) ? body.status : null;
    let progress = Number.parseInt(body.progress, 10);
    if (!name || name.length < 3) errors.push('اسم المشروع مطلوب (3 أحرف على الأقل)');
    if (!clientId || !queryOne("SELECT id FROM clients WHERE id = ?", [clientId])) errors.push('يرجى اختيار عميل صحيح');
    if (!status) errors.push('حالة المشروع غير صحيحة');
    if (Number.isNaN(progress)) progress = status === 'completed' ? 100 : 0;
    progress = Math.max(0, Math.min(100, progress));
    return { errors, value: { name, description, clientId, status, progress, start_date: body.start_date || null, due_date: body.due_date || null } };
}

function clientWithDetails(c) {
    return {
        ...c,
        projects_count: queryOne("SELECT COUNT(*) AS c FROM projects WHERE client_id = ?", [c.id])?.c || 0,
        linked_username: c.linked_username || null,
        linked_user_name: c.linked_user_name || null
    };
}

// Team members available for assignment (admin + employee accounts)
app.get('/api/team-members', requireAuth, requirePermission('projects.assign', 'projects.view.all'), (req, res) => {
    res.json({ success: true, data: queryAll(`SELECT id, username, full_name, email, role
        FROM users WHERE role IN ('admin','employee') ORDER BY role = 'admin' DESC, full_name`) });
});

// Clients CRUD
app.get('/api/clients', requireAuth, requirePermission('clients.view'), (req, res) => {
    const { search, status } = req.query;
    let rows = queryAll(`SELECT c.*, u.username AS linked_username, u.full_name AS linked_user_name
                         FROM clients c LEFT JOIN users u ON u.id = c.user_id ORDER BY c.id DESC`);
    if (search) {
        const q = String(search).toLowerCase();
        rows = rows.filter(c => [c.company, c.name, c.email, c.phone].some(v => String(v || '').toLowerCase().includes(q)));
    }
    if (status === 'active' || status === 'inactive') rows = rows.filter(c => c.status === status);
    res.json({ success: true, data: rows.map(clientWithDetails) });
});

app.post('/api/clients', requireAuth, requirePermission('clients.manage'), (req, res) => {
    const company = (req.body.company || '').trim();
    const name = (req.body.name || '').trim();
    const email = (req.body.email || '').trim();
    const phone = (req.body.phone || '').trim();
    const notes = (req.body.notes || '').trim();
    const status = req.body.status === 'inactive' ? 'inactive' : 'active';
    const userId = req.body.user_id ? parseInt(req.body.user_id, 10) : null;
    const errors = [];
    if (company.length < 2) errors.push('اسم الشركة مطلوب');
    if (name.length < 2) errors.push('اسم مسؤول التواصل مطلوب');
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('البريد الإلكتروني غير صحيح');
    if (userId && !queryOne("SELECT id FROM users WHERE id = ? AND role = 'customer'", [userId])) errors.push('حساب العميل المرتبط غير موجود أو ليس دوره customer');
    if (errors.length) return res.status(400).json({ success: false, message: 'بيانات العميل غير مكتملة', errors });

    db.run(`INSERT INTO clients (company, name, email, phone, user_id, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [company, name, email, phone, userId, notes, status]);
    const id = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    saveDatabase();
    const c = queryOne(`SELECT c.*, u.username AS linked_username, u.full_name AS linked_user_name FROM clients c
                        LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?`, [id]);
    res.status(201).json({ success: true, message: 'تم إضافة العميل بنجاح', data: clientWithDetails(c) });
});

app.get('/api/clients/:id', requireAuth, (req, res) => {
    const c = queryOne(`SELECT c.*, u.username AS linked_username, u.full_name AS linked_user_name FROM clients c
                        LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?`, [req.params.id]);
    if (!c) return res.status(404).json({ success: false, message: 'العميل غير موجود' });
    if (!hasPermission(req.user, 'clients.view') && c.user_id !== req.user.id) {
        return res.status(403).json({ success: false, message: 'لا يمكنك عرض بيانات هذا العميل' });
    }
    res.json({ success: true, data: clientWithDetails(c) });
});

app.put('/api/clients/:id', requireAuth, requirePermission('clients.manage'), (req, res) => {
    const existing = queryOne("SELECT * FROM clients WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العميل غير موجود' });
    const company = (req.body.company ?? existing.company).trim();
    const name = (req.body.name ?? existing.name).trim();
    const email = (req.body.email ?? existing.email ?? '').trim();
    const phone = (req.body.phone ?? existing.phone ?? '').trim();
    const notes = (req.body.notes ?? existing.notes ?? '').trim();
    const status = ['active','inactive'].includes(req.body.status) ? req.body.status : existing.status;
    const userId = req.body.user_id !== undefined ? (req.body.user_id ? parseInt(req.body.user_id, 10) : null) : existing.user_id;
    if (company.length < 2 || name.length < 2) return res.status(400).json({ success: false, message: 'اسم الشركة ومسؤول التواصل مطلوبان' });
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ success: false, message: 'البريد الإلكتروني غير صحيح' });
    if (userId && !queryOne("SELECT id FROM users WHERE id = ? AND role = 'customer'", [userId])) return res.status(400).json({ success: false, message: 'حساب العميل المرتبط غير صالح' });

    db.run(`UPDATE clients SET company=?, name=?, email=?, phone=?, user_id=?, notes=?, status=?, updated_at=datetime('now') WHERE id=?`,
        [company, name, email, phone, userId, notes, status, existing.id]);
    saveDatabase();
    const c = queryOne(`SELECT c.*, u.username AS linked_username, u.full_name AS linked_user_name FROM clients c
                        LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?`, [existing.id]);
    res.json({ success: true, message: 'تم تحديث بيانات العميل', data: clientWithDetails(c) });
});

app.delete('/api/clients/:id', requireAuth, requirePermission('clients.manage'), (req, res) => {
    const c = queryOne("SELECT * FROM clients WHERE id = ?", [req.params.id]);
    if (!c) return res.status(404).json({ success: false, message: 'العميل غير موجود' });
    const projectsCount = queryOne("SELECT COUNT(*) AS c FROM projects WHERE client_id = ?", [c.id])?.c || 0;
    if (projectsCount > 0) return res.status(400).json({ success: false, message: `لا يمكن حذف العميل لأنه مرتبط بـ ${projectsCount} مشروع` });
    db.run("DELETE FROM clients WHERE id = ?", [c.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف العميل' });
});

// Scoped project dashboard summary (must be registered before /:id)
app.get('/api/projects/summary', requireAuth, (req, res) => {
    const rows = accessibleProjectsForUser(req.user);
    const counts = Object.fromEntries(PROJECT_STATUSES.map(s => [s, 0]));
    rows.forEach(p => counts[p.status]++);
    const avg = rows.length ? Math.round(rows.reduce((sum, p) => sum + Number(p.progress || 0), 0) / rows.length) : 0;
    res.json({ success: true, data: { total: rows.length, counts, avg_progress: avg } });
});

// Projects list with backend filters
app.get('/api/projects', requireAuth, (req, res) => {
    const rows = accessibleProjectsForUser(req.user, req.query).map(projectWithDetails);
    const counts = Object.fromEntries(PROJECT_STATUSES.map(s => [s, 0]));
    rows.forEach(p => counts[p.status]++);
    res.json({ success: true, data: rows, total: rows.length, counts, statuses: PROJECT_STATUSES });
});

// Create project
app.post('/api/projects', requireAuth, requirePermission('projects.create'), (req, res) => {
    const { errors, value } = validateProjectPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'يرجى تصحيح بيانات المشروع', errors });

    db.run(`INSERT INTO projects (name, description, client_id, status, progress, start_date, due_date, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [value.name, value.description, value.clientId, value.status, value.progress, value.start_date, value.due_date, req.user.id]);
    const id = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    setProjectMembers(id, req.body.assigned_to);
    saveDatabase();
    const p = queryOne(projectBaseQuery() + " WHERE p.id = ?", [id]);
    res.status(201).json({ success: true, message: 'تم إنشاء المشروع بنجاح', data: projectWithDetails(p) });
});

app.get('/api/projects/:id', requireAuth, (req, res) => {
    const p = queryOne(projectBaseQuery() + " WHERE p.id = ?", [req.params.id]);
    if (!p) return res.status(404).json({ success: false, message: 'المشروع غير موجود' });
    if (!canAccessProject(req.user, p)) return res.status(403).json({ success: false, message: 'لا يمكنك الوصول إلى هذا المشروع' });
    res.json({ success: true, data: projectWithDetails(p) });
});

// Full project update
app.put('/api/projects/:id', requireAuth, requirePermission('projects.update'), (req, res) => {
    const existing = queryOne("SELECT * FROM projects WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'المشروع غير موجود' });
    const { errors, value } = validateProjectPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'يرجى تصحيح بيانات المشروع', errors });
    if (Array.isArray(req.body.assigned_to) && !hasPermission(req.user, 'projects.assign')) {
        return res.status(403).json({ success: false, message: 'لا تملك صلاحية تعديل أعضاء الفريق المعينين' });
    }

    db.run(`UPDATE projects SET name=?, description=?, client_id=?, status=?, progress=?, start_date=?, due_date=?, updated_at=datetime('now')
            WHERE id=?`, [value.name, value.description, value.clientId, value.status, value.progress, value.start_date, value.due_date, existing.id]);
    if (Array.isArray(req.body.assigned_to)) setProjectMembers(existing.id, req.body.assigned_to);
    saveDatabase();
    const p = queryOne(projectBaseQuery() + " WHERE p.id = ?", [existing.id]);
    res.json({ success: true, message: 'تم تحديث المشروع بنجاح', data: projectWithDetails(p) });
});

// Status + progress update
app.put('/api/projects/:id/status', requireAuth, requirePermission('projects.update.status'), (req, res) => {
    const existing = queryOne("SELECT * FROM projects WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'المشروع غير موجود' });
    const status = req.body.status;
    if (!PROJECT_STATUSES.includes(status)) return res.status(400).json({ success: false, message: 'حالة المشروع غير صحيحة', valid: PROJECT_STATUSES });
    let progress = Number.parseInt(req.body.progress, 10);
    if (Number.isNaN(progress)) progress = existing.progress;
    progress = Math.max(0, Math.min(100, progress));
    if (status === 'completed') progress = 100;
    if (status === 'not_started') progress = 0;

    db.run(`UPDATE projects SET status=?, progress=?, updated_at=datetime('now') WHERE id=?`, [status, progress, existing.id]);
    saveDatabase();
    const p = queryOne(projectBaseQuery() + " WHERE p.id = ?", [existing.id]);
    res.json({ success: true, message: 'تم تحديث حالة المشروع ونسبة الإنجاز', data: projectWithDetails(p) });
});

// Delete project
app.delete('/api/projects/:id', requireAuth, requirePermission('projects.delete'), (req, res) => {
    const p = queryOne("SELECT * FROM projects WHERE id = ?", [req.params.id]);
    if (!p) return res.status(404).json({ success: false, message: 'المشروع غير موجود' });
    db.run("DELETE FROM project_members WHERE project_id = ?", [p.id]);
    db.run("DELETE FROM projects WHERE id = ?", [p.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف المشروع بنجاح' });
});

// ==================== TASK 10: FILE & DOCUMENT MANAGEMENT API ====================
// Authenticated upload -> server-side validation -> disk storage + DB record.
// Listing / download / delete are all permission-checked (integrated with Task 9 RBAC).

const ALLOWED_EXTENSIONS = new Set([
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',   // documents
    'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg',           // images
    'txt', 'csv', 'zip'                                   // misc
]);
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const FILE_CATEGORIES = ['general', 'contract', 'invoice', 'design', 'report', 'other'];

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
        // Stored with a random name; original name is kept in the DB.
        const ext = (file.originalname.split('.').pop() || '').toLowerCase();
        cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: MAX_FILE_SIZE, files: 1 },
    fileFilter: (req, file, cb) => {
        const ext = (file.originalname.split('.').pop() || '').toLowerCase();
        if (!ALLOWED_EXTENSIONS.has(ext)) {
            return cb(new Error(`نوع الملف غير مسموح (.${ext}) — الأنواع المسموحة: ${[...ALLOWED_EXTENSIONS].join(', ')}`));
        }
        cb(null, true);
    }
});

function fileRecord(f, uploader) {
    return {
        id: f.id,
        original_name: f.original_name,
        mime_type: f.mime_type,
        size: f.size,
        extension: f.extension,
        category: f.category,
        description: f.description,
        created_at: f.created_at,
        uploader_id: f.user_id,
        uploader_name: uploader?.full_name || f.uploader_name || null,
        uploader_username: uploader?.username || f.uploader_username || null
    };
}

function removeFileFromDisk(storedName) {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, storedName)); } catch (e) { /* already gone */ }
}

// Upload a file (authenticated + files.upload permission)
app.post('/api/files', requireAuth, requirePermission('files.upload'), (req, res) => {
    upload.single('file')(req, res, (err) => {
        if (err) {
            const msg = err.code === 'LIMIT_FILE_SIZE'
                ? `حجم الملف يتجاوز الحد الأقصى المسموح (${MAX_FILE_SIZE / 1024 / 1024}MB)`
                : (err.message || 'فشل معالجة الملف');
            return res.status(400).json({ success: false, message: msg });
        }
        if (!req.file) {
            return res.status(400).json({ success: false, message: 'لم يتم إرفاق أي ملف — حقل "file" مطلوب' });
        }

        const category = FILE_CATEGORIES.includes(req.body.category) ? req.body.category : 'general';
        const description = (req.body.description || '').trim().slice(0, 500);
        const ext = (req.file.originalname.split('.').pop() || '').toLowerCase();
        // Decode latin1 -> utf8 so Arabic original filenames survive multipart transport
        const originalName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');

        db.run(`INSERT INTO files (user_id, original_name, stored_name, mime_type, size, extension, category, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.user.id, originalName, req.file.filename, req.file.mimetype, req.file.size, ext, category, description]);
        // NOTE: capture the id BEFORE saveDatabase() — db.export() resets last_insert_rowid()
        const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
        saveDatabase();

        const f = queryOne("SELECT * FROM files WHERE id = ?", [newId]);
        res.status(201).json({ success: true, message: 'تم رفع الملف بنجاح', data: fileRecord(f, req.user) });
    });
});

// My files (files.view.own)
app.get('/api/files/mine', requireAuth, requirePermission('files.view.own'), (req, res) => {
    const rows = queryAll("SELECT * FROM files WHERE user_id = ? ORDER BY id DESC", [req.user.id]);
    res.json({ success: true, data: rows.map(f => fileRecord(f, req.user)) });
});

// All files (files.view.all — company side)
app.get('/api/files', requireAuth, requirePermission('files.view.all'), (req, res) => {
    const { search, category, user_id } = req.query;
    let sql = `SELECT f.*, u.full_name AS uploader_name, u.username AS uploader_username
               FROM files f JOIN users u ON u.id = f.user_id WHERE 1=1`;
    const params = [];
    if (search && search.trim()) { sql += " AND (f.original_name LIKE ? OR f.description LIKE ?)"; params.push(`%${search.trim()}%`, `%${search.trim()}%`); }
    if (category && FILE_CATEGORIES.includes(category)) { sql += " AND f.category = ?"; params.push(category); }
    if (user_id && !isNaN(parseInt(user_id))) { sql += " AND f.user_id = ?"; params.push(parseInt(user_id)); }
    sql += " ORDER BY f.id DESC";
    res.json({ success: true, data: queryAll(sql, params).map(f => fileRecord(f)) });
});

// Download (owner OR anyone with files.view.all)
app.get('/api/files/:id/download', requireAuth, (req, res) => {
    const f = queryOne("SELECT * FROM files WHERE id = ?", [req.params.id]);
    if (!f) return res.status(404).json({ success: false, message: 'الملف غير موجود' });
    if (f.user_id !== req.user.id && !hasPermission(req.user, 'files.view.all')) {
        return res.status(403).json({ success: false, message: 'لا يمكنك تحميل ملفات مستخدمين آخرين' });
    }
    const full = path.join(UPLOAD_DIR, f.stored_name);
    if (!fs.existsSync(full)) return res.status(410).json({ success: false, message: 'الملف مفقود من وحدة التخزين' });
    res.download(full, f.original_name);
});

// Delete (owner + files.delete.own, or files.delete.any for admins)
app.delete('/api/files/:id', requireAuth, (req, res) => {
    const f = queryOne("SELECT * FROM files WHERE id = ?", [req.params.id]);
    if (!f) return res.status(404).json({ success: false, message: 'الملف غير موجود' });

    const isOwner = f.user_id === req.user.id;
    const allowed = (isOwner && hasPermission(req.user, 'files.delete.own')) || hasPermission(req.user, 'files.delete.any');
    if (!allowed) {
        return res.status(403).json({ success: false, message: 'لا يمكنك حذف هذا الملف — يتطلب ملكية الملف أو صلاحية files.delete.any' });
    }

    db.run("DELETE FROM files WHERE id = ?", [f.id]);
    removeFileFromDisk(f.stored_name);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الملف بنجاح' });
});

// ==================== START ====================
app.get('/api/health', (req, res) => res.json({ success: true, status: 'running' }));

app.use('/api', (req, res) => res.status(404).json({ success: false, message: 'API endpoint غير موجود' }));

(async () => {
    await loadDatabase();
    app.listen(PORT, () => {
        console.log('=================================================');
        console.log('  NexaTech Solutions - Backend Running (Tasks 3-11)');
        console.log(`  Website:          http://localhost:${PORT}`);
        console.log(`  Customer Dashboard: http://localhost:${PORT}/dashboard.html`);
        console.log(`  Admin Panel:      http://localhost:${PORT}/admin`);
        console.log(`  Requests Mgmt:    http://localhost:${PORT}/admin/requests.html`);
        console.log(`  Projects Platform:http://localhost:${PORT}/projects.html`);
        console.log(`  Projects Admin:   http://localhost:${PORT}/admin/projects.html`);
        console.log(`  User Roles (T9):  http://localhost:${PORT}/admin/users.html`);
        console.log(`  Roles & Perms(T9):http://localhost:${PORT}/admin/roles.html`);
        console.log(`  My Files (T10):   http://localhost:${PORT}/files.html`);
        console.log(`  All Files (T10):  http://localhost:${PORT}/admin/files.html`);
        console.log('  Admin Login:      admin / admin123');
        console.log('  Employee Login:   employee1 / Emp12345');
        console.log('=================================================');
    });
})();
