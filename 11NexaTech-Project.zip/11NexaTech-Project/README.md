# NexaTech Solutions — Task 11

## منصة إدارة مشاريع العملاء — Full-Stack Client Project Management Platform

هذا المجلد يحتوي على المشروع النهائي بعد دمج Task 11 مع جميع الأعمال السابقة Tasks 3–10. النظام يشمل Frontend وBackend وDatabase وAuthentication وRole-Based Permissions وREST APIs.

## المزايا المنفذة في Task 11

- تسجيل الدخول وحماية الصفحات والـ APIs باستخدام Token.
- صلاحيات مبنية على Roles:
  - **Admin**: كل الصلاحيات بما فيها إنشاء المشاريع والعملاء والحذف وتعيين الفريق.
  - **Employee / Team Member**: عرض وتحديث حالة المشروع ونسبة الإنجاز وتعيين الفريق.
  - **Customer**: عرض المشاريع المرتبطة بحسابه فقط.
- إدارة العملاء CRUD.
- إدارة المشاريع CRUD مع ربط كل مشروع بعميل.
- تحديد حالة المشروع:
  - `not_started`
  - `in_progress`
  - `completed`
  - `on_hold`
- تخزين نسبة تقدم المشروع من 0 إلى 100.
- تعيين Team Member واحد أو أكثر لكل مشروع.
- Dashboard تعرض إجمالي المشاريع، المشاريع قيد التنفيذ، المكتملة، المتوقفة، ومتوسط الإنجاز.
- عزل البيانات في API: المستخدم يرى فقط المشاريع التي يملك صلاحية الوصول إليها.
- استخدام Database لحفظ المستخدمين والأدوار والعملاء والمشاريع وعلاقاتهم.
- الحفاظ على Task 10 الخاص بإدارة الملفات، بما فيه إضافة صفحة `admin/files.html` التي كانت ناقصة.

## التقنيات

- Frontend: HTML5, CSS3, JavaScript, RTL Arabic UI.
- Backend: Node.js + Express.
- Database: SQLite عبر sql.js مع حفظ الملف في `data/nexatech.db`.
- Authentication: Token Sessions + SHA-256.
- Uploads: Multer.
- Reports: Microsoft Word DOCX.

## التشغيل السريع

### الطريقة الأسهل على Windows

شغّل الملف:

```bat
run.bat
```

سيقوم الملف تلقائيًا بتثبيت الحزم إذا لم تكن موجودة ثم تشغيل السيرفر.

### الطريقة اليدوية

```bash
cd server
npm install
npm start
```

ثم افتح:

- الموقع الرئيسي: `http://localhost:3000/`
- تسجيل الدخول: `http://localhost:3000/login.html`
- منصة المشاريع: `http://localhost:3000/projects.html`
- إدارة المشاريع للمسؤول: `http://localhost:3000/admin/projects.html`
- لوحة العميل: `http://localhost:3000/dashboard.html`
- لوحة الإدارة: `http://localhost:3000/admin`
- إدارة الملفات: `http://localhost:3000/files.html`
- كل ملفات المنصة: `http://localhost:3000/admin/files.html`

## حسابات تجريبية

| الدور | اسم المستخدم | كلمة المرور | الصلاحيات الأساسية |
|---|---|---|---|
| Admin | `admin` | `admin123` | كل الصلاحيات |
| Team Member | `employee1` | `Emp12345` | متابعة وتحديث المشاريع وتعيين الفريق |
| Customer | `customer1` | `Demo1234` | عرض مشاريعه فقط |
| Customer سابق | `demo_customer` | `Demo1234` | عرض مشاريعه فقط |

## أهم API Endpoints

| Method | Endpoint | الوصف | الصلاحية |
|---|---|---|---|
| POST | `/api/login` | تسجيل الدخول وإرجاع Token | عام |
| GET | `/api/me/permissions` | بيانات المستخدم وصلاحياته | Auth |
| GET | `/api/projects` | قائمة المشاريع حسب نطاق صلاحية المستخدم | Auth |
| POST | `/api/projects` | إنشاء مشروع جديد | `projects.create` |
| GET | `/api/projects/summary` | إحصائيات Dashboard | Auth |
| GET | `/api/projects/:id` | تفاصيل مشروع | عضو / عميل / فريق |
| PUT | `/api/projects/:id` | تعديل بيانات المشروع وربطه وتعيين الفريق | `projects.update` + `projects.assign` للتعيين |
| PUT | `/api/projects/:id/status` | تحديث الحالة ونسبة الإنجاز | `projects.update.status` |
| DELETE | `/api/projects/:id` | حذف المشروع | `projects.delete` |
| GET | `/api/clients` | عرض العملاء | `clients.view` |
| POST | `/api/clients` | إضافة عميل | `clients.manage` |
| PUT | `/api/clients/:id` | تعديل عميل | `clients.manage` |
| DELETE | `/api/clients/:id` | حذف عميل غير مرتبط بمشاريع | `clients.manage` |
| GET | `/api/team-members` | المستخدمون القابلون للتعيين | `projects.assign` أو `projects.view.all` |

## قاعدة البيانات

الجداول المضافة/المستخدمة في Task 11:

- `clients`
  - `id`, `company`, `name`, `email`, `phone`, `user_id`, `notes`, `status`
- `projects`
  - `id`, `name`, `description`, `client_id`, `status`, `progress`, `start_date`, `due_date`, `created_by`
- `project_members`
  - `project_id`, `user_id`

العلاقات:

- عميل واحد يمكن أن يملك عدة مشاريع `1:N`.
- مشروع واحد مرتبط بعميل واحد `N:1`.
- المشروع والمستخدمون علاقة Many-to-Many عبر `project_members`.
- العميل يمكن ربطه بحساب مستخدم عبر `clients.user_id`.

## نتائج الاختبار

تم تشغيل السيرفر والتحقق من:

- إنشاء الجداول والبيانات التجريبية.
- تسجيل دخول Admin.
- عرض 5 مشاريع Demo.
- عرض 4 عملاء Demo.
- صلاحيات Admin الكاملة.
- تسجيل دخول العميل `customer1`.
- عرض العميل لمشروعين فقط المرتبطين بحسابه.
- Dashboard ترجع إحصائيات صحيحة.

## بنية المشروع

```text
NexaTech-Project/
├─ index.html
├─ login.html
├─ register.html
├─ dashboard.html
├─ projects.html
├─ request.html
├─ files.html
├─ profile.html
├─ run.bat
├─ css/style.css
├─ js/script.js
├─ images/
├─ data/nexatech.db
├─ server/
│  ├─ server.js
│  ├─ package.json
│  └─ package-lock.json
├─ admin/
│  ├─ index.html
│  ├─ projects.html
│  ├─ requests.html
│  ├─ services.html
│  ├─ files.html
│  ├─ users.html
│  └─ roles.html
├─ docs/
│  ├─ Task-10-Report.pdf
│  ├─ Task-11-Report.docx
│  └─ screenshots/
└─ archive/
   ├─ task10_routes.js
   ├─ package1.json
   └─ package-lock1.json
```

## ملاحظات

- لا يستطيع المستخدم غير المسجل دخوله الوصول للبيانات المحمية.
- لا يستطيع العميل تنفيذ إنشاء أو تعديل أو حذف المشاريع.
- لا يستطيع الموظف حذف المشاريع؛ هذه الصلاحية للمدير فقط.
- لا يمكن حذف عميل مرتبط بمشاريع لحماية تكامل البيانات.
- عند تغيير الحالة إلى `completed` تصبح نسبة الإنجاز 100% تلقائيًا.
- عند تغيير الحالة إلى `not_started` تصبح نسبة الإنجاز 0% تلقائيًا.

## تسليم Task 11

تم دمج كل التعديلات داخل نفس المشروع السابق، وإصلاح الملفات الناقصة، وتجهيز ZIP نهائي + تقرير Word + لقطات شاشة من بيئة التشغيل.
