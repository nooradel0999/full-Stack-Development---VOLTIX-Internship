/**
 * NexaTech Solutions - Full Stack Platform
 * Task 3: Content Management + Task 5: Customer Dashboard
 * Task 6: Company Service Management (Services CRUD + Public Website sync)
 * Task 7: Customer Request Management (Customer-side submission + Company-side management)
 * Task 8: Search & Filtering for Company Data (Backend-driven search + multi-criteria filters)
 * Express + SQLite (sql.js)
 * Author: Nooraleeman Adel Al-shawesh
 * Date: September 2026
 *
 * Run: npm install && node server.js
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const initSqlJs = require('sql.js');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const DB_PATH = path.join(ROOT, 'data', 'nexatech.db');

// ==================== DATABASE (SQLite) ====================
let db;
const sessions = {}; // token -> safe user object

async function loadDatabase() {
    const SQL = await initSqlJs();
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

    if (fs.existsSync(DB_PATH)) {
        const filebuffer = fs.readFileSync(DB_PATH);
        db = new SQL.Database(filebuffer);
        console.log('✓ Database loaded from data/nexatech.db');
    } else {
        db = new SQL.Database();
        console.log('✓ New database created');
    }

    createTables();
    migrateUsersTable();
    seedDatabase();
    saveDatabase();
}

function saveDatabase() {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function createTables() {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            role TEXT DEFAULT 'customer',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS content_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            image TEXT,
            icon TEXT,
            status TEXT DEFAULT 'published' CHECK(status IN ('published','draft')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    // ==================== TASK 6: SERVICES TABLE ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            icon TEXT DEFAULT 'fa-code',
            image TEXT,
            features TEXT,
            status TEXT DEFAULT 'active' CHECK(status IN ('active','inactive')),
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            subject TEXT,
            message TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
    `);
    // ==================== TASK 7: CUSTOMER REQUESTS TABLE ====================
    db.run(`
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            service_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high')),
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_review','in_progress','completed','cancelled')),
            admin_notes TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (service_id) REFERENCES services(id)
        );
    `);
}

function ensureColumn(table, column, ddl) {
    const result = db.exec(`PRAGMA table_info(${table})`)[0];
    if (!result) return;
    const exists = result.values.some(row => row[1] === column);
    if (!exists) {
        db.run(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
        console.log(`✓ Column added: ${table}.${column}`);
    }
}

function migrateUsersTable() {
    ensureColumn('users', 'email', 'TEXT');
    ensureColumn('users', 'phone', 'TEXT');
    ensureColumn('users', 'updated_at', "TEXT DEFAULT (datetime('now'))");
    db.run("UPDATE users SET role = 'customer' WHERE role IS NULL OR role = ''");
}

function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

function seedDatabase() {
    const users = db.exec("SELECT COUNT(*) AS c FROM users");
    if (users[0].values[0][0] === 0) {
        db.run(`INSERT INTO users
            (username, password, full_name, email, role)
            VALUES (?, ?, ?, ?, ?)`,
            ['admin', hashPassword('admin123'), 'Nooraleeman Adel Al-shawesh', 'admin@nexatech.local', 'admin']);
        console.log('✓ Default admin user created (admin / admin123)');
    }

    const items = db.exec("SELECT COUNT(*) AS c FROM content_items");
    if (items[0].values[0][0] === 0) {
        const seed = [
            ['Web Development', 'service', 'Custom web applications built with modern frameworks and best practices.', 'images/web-dev.png', 'fa-code', 'published'],
            ['Mobile Apps', 'service', 'Native and cross-platform mobile applications for iOS and Android.', 'images/mobile-app.png', 'fa-mobile-alt', 'published'],
            ['Cloud Solutions', 'service', 'Scalable cloud infrastructure and migration services.', 'images/cloud-computing.png', 'fa-cloud', 'published'],
            ['Digital Marketing', 'service', 'Data-driven marketing strategies that increase visibility and conversions.', 'images/digital-marketing.png', 'fa-bullhorn', 'published'],
            ['UI/UX Design', 'service', 'Beautiful, intuitive interfaces that delight users.', 'images/marketing-3d.png', 'fa-paint-brush', 'published'],
            ['IT Consulting', 'service', 'Strategic technology consulting to align IT with business goals.', 'images/team-coding.png', 'fa-chart-pie', 'published'],
            ['E-Commerce Platform', 'project', 'Full-stack web application', 'images/web-dev.png', null, 'published'],
            ['Travel Booking App', 'project', 'Cross-platform mobile app', 'images/mobile-app.png', null, 'published'],
            ['Cloud Migration', 'project', 'Enterprise cloud solution', 'images/cloud-computing.png', null, 'published'],
            ['Marketing Dashboard', 'project', 'Analytics platform', 'images/digital-marketing.png', null, 'draft'],
        ];
        const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
        seed.forEach(row => stmt.run(row));
        stmt.free();
        console.log('✓ Content items seeded');
    }

    seedServices();
    seedRequests();
}

// ==================== TASK 7: SAMPLE REQUESTS SEED ====================
function seedRequests() {
    const c = db.exec("SELECT COUNT(*) AS c FROM requests");
    if (c[0].values[0][0] > 0) return;
    const customer = queryOne("SELECT id FROM users WHERE username = 'admin'");
    // Create a demo customer if none exists (so requests have a real owner)
    let custId = customer ? null : null;
    const anyCustomer = queryOne("SELECT id FROM users WHERE role = 'customer' LIMIT 1");
    if (!anyCustomer) {
        db.run(`INSERT INTO users (username, password, full_name, email, phone, role)
                VALUES (?, ?, ?, ?, ?, 'customer')`,
            ['demo_customer', hashPassword('Demo1234'), 'عميل تجريبي', 'demo@nexatech.local', '0500000000']);
        custId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
        console.log('✓ Demo customer created (demo_customer / Demo1234)');
    } else {
        custId = anyCustomer.id;
    }
    const svc = (n) => queryOne("SELECT id FROM services WHERE title = ?", [n])?.id || null;
    const seed = [
        [custId, svc('Web Development'), 'تطوير موقع شركة احترافي', 'نحتاج موقعًا تعريفيًا متكاملًا مع لوحة تحكم وربط بنظام الحجوزات.', 'high', 'in_progress', 'تم التواصل مع العميل وتحديد المتطلبات، جارٍ العمل على التصميم.'],
        [custId, svc('Mobile Apps'), 'تطبيق جوال لتوصيل الطلبات', 'تطبيق iOS وAndroid لشركة توصيل محلية مع تتبع مباشر للسائقين.', 'medium', 'pending', null],
        [custId, svc('Cloud Solutions'), 'نقل البنية التحتية للسحابة', 'ترحيل خوادمنا الحالية إلى AWS مع ضمان عدم توقف الخدمة.', 'medium', 'in_review', 'جارٍ تقييم البنية الحالية وإعداد خطة الترحيل.'],
        [custId, svc('Digital Marketing'), 'حملة تسويقية ربع سنوية', 'إدارة الحملات الإعلانية على منصات التواصل مع تقارير شهرية.', 'low', 'completed', 'تم إنجاز الحملة بنجاح ورفع التقرير النهائي.'],
        [custId, svc('UI/UX Design'), 'إعادة تصميم واجهة المتجر الإلكتروني', 'تحسين تجربة المستخدم ورفع معدل إتمام عمليات الشراء.', 'high', 'pending', null],
    ];
    const stmt = db.prepare(`INSERT INTO requests (user_id, service_id, title, description, priority, status, admin_notes)
                             VALUES (?, ?, ?, ?, ?, ?, ?)`);
    seed.forEach(r => stmt.run(r));
    stmt.free();
    console.log('✓ Sample requests seeded');
}

// ==================== TASK 6: SERVICES SEED ====================
function seedServices() {
    const c = db.exec("SELECT COUNT(*) AS c FROM services");
    if (c[0].values[0][0] > 0) return;
    const seed = [
        ['Web Development', 'Custom web applications built with modern frameworks and best practices. From simple landing pages to complex enterprise solutions.', 'fa-code', 'images/web-dev.png', 'Responsive Design|SEO Optimized|High Performance'],
        ['Mobile Apps', 'Native and cross-platform mobile applications for iOS and Android. Engaging user experiences that drive retention and growth.', 'fa-mobile-alt', 'images/mobile-app.png', 'iOS & Android|Cross-Platform|UI/UX Design'],
        ['Cloud Solutions', 'Scalable cloud infrastructure and migration services. Optimize costs and improve reliability with our cloud expertise.', 'fa-cloud', 'images/cloud-computing.png', 'AWS & Azure|Cloud Migration|DevOps'],
        ['Digital Marketing', 'Data-driven marketing strategies that increase visibility and conversions. SEO, PPC, social media, and content marketing.', 'fa-bullhorn', 'images/digital-marketing.png', 'SEO & SEM|Social Media|Analytics'],
        ['UI/UX Design', 'Beautiful, intuitive interfaces that delight users. User-centered design process from research to prototyping.', 'fa-paint-brush', 'images/marketing-3d.png', 'User Research|Prototyping|Design Systems'],
        ['IT Consulting', 'Strategic technology consulting to align IT with business goals. Digital transformation and process optimization.', 'fa-chart-pie', 'images/team-coding.png', 'Strategy|Architecture|Optimization'],
    ];
    const stmt = db.prepare("INSERT INTO services (title, description, icon, image, features) VALUES (?, ?, ?, ?, ?)");
    seed.forEach(r => stmt.run(r));
    stmt.free();
    console.log('✓ Services seeded');
}

function queryAll(sql, params = []) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
}

function queryOne(sql, params = []) {
    return queryAll(sql, params)[0] || null;
}

function safeUser(user) {
    if (!user) return null;
    return {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        created_at: user.created_at,
        updated_at: user.updated_at
    };
}

// ==================== MIDDLEWARE ====================
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

function requireAuth(req, res, next) {
    const token = req.headers['authorization']?.replace('Bearer ', '');
    const sessionUser = token && sessions[token];

    if (!sessionUser) {
        return res.status(401).json({ success: false, message: 'غير مصرح - يرجى تسجيل الدخول أولاً' });
    }

    const freshUser = queryOne("SELECT * FROM users WHERE id = ?", [sessionUser.id]);
    if (!freshUser) {
        delete sessions[token];
        return res.status(401).json({ success: false, message: 'المستخدم غير موجود أو انتهت الجلسة' });
    }

    req.token = token;
    req.user = safeUser(freshUser);
    next();
}

function requireAdmin(req, res, next) {
    if (req.user?.role === 'admin') return next();
    return res.status(403).json({ success: false, message: 'هذه العملية متاحة للمدير فقط' });
}

app.use(express.static(ROOT));

// ==================== AUTH API ====================
app.post('/api/register', (req, res) => {
    const fullName = (req.body.fullName || '').trim();
    const username = (req.body.username || '').trim();
    const email = (req.body.email || '').trim();
    const password = req.body.password || '';
    const confirmPassword = req.body.confirmPassword || '';

    const errors = [];
    if (fullName.length < 3) errors.push('الاسم الكامل مطلوب ويجب ألا يقل عن 3 أحرف');
    if (!/^[a-zA-Z0-9_.-]{3,30}$/.test(username)) errors.push('اسم المستخدم يجب أن يكون إنجليزيًا من 3 إلى 30 حرفًا');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('البريد الإلكتروني غير صحيح');
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) errors.push('كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي حرفًا ورقمًا');
    if (password !== confirmPassword) errors.push('تأكيد كلمة المرور غير مطابق');

    if (errors.length) {
        return res.status(400).json({ success: false, message: 'يرجى تصحيح الأخطاء التالية', errors });
    }

    if (queryOne("SELECT id FROM users WHERE LOWER(username) = LOWER(?)", [username])) {
        errors.push('اسم المستخدم مستخدم مسبقًا');
    }
    if (queryOne("SELECT id FROM users WHERE LOWER(COALESCE(email,'')) = LOWER(?)", [email])) {
        errors.push('البريد الإلكتروني مستخدم مسبقًا');
    }
    if (errors.length) {
        return res.status(400).json({ success: false, message: 'يرجى تصحيح الأخطاء التالية', errors });
    }

    db.run(`INSERT INTO users (username, password, full_name, email, role)
            VALUES (?, ?, ?, ?, 'customer')`,
        [username, hashPassword(password), fullName, email]);
    saveDatabase();

    const user = queryOne("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", [username]);
    const token = crypto.randomBytes(24).toString('hex');
    sessions[token] = safeUser(user);

    res.status(201).json({ success: true, message: 'تم إنشاء الحساب بنجاح', token, user: sessions[token] });
});

app.post('/api/login', (req, res) => {
    const usernameOrEmail = (req.body.username || req.body.email || '').trim();
    const password = req.body.password || '';

    if (!usernameOrEmail || !password) {
        return res.status(400).json({ success: false, message: 'يرجى إدخال اسم المستخدم أو البريد الإلكتروني وكلمة المرور' });
    }

    const user = queryOne(`SELECT * FROM users
        WHERE LOWER(username) = LOWER(?) OR LOWER(COALESCE(email, '')) = LOWER(?)`,
        [usernameOrEmail, usernameOrEmail]);

    if (!user || user.password !== hashPassword(password)) {
        return res.status(401).json({ success: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    const token = crypto.randomBytes(24).toString('hex');
    sessions[token] = safeUser(user);
    res.json({ success: true, token, user: sessions[token] });
});

app.post('/api/logout', requireAuth, (req, res) => {
    delete sessions[req.token];
    res.json({ success: true, message: 'تم تسجيل الخروج بنجاح' });
});

app.get('/api/me', requireAuth, (req, res) => {
    res.json({ success: true, user: req.user });
});

app.put('/api/profile', requireAuth, (req, res) => {
    const fullName = (req.body.fullName || '').trim();
    const email = (req.body.email || '').trim();
    const phone = (req.body.phone || '').trim();

    const errors = [];
    if (fullName.length < 3) errors.push('الاسم الكامل مطلوب');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('البريد الإلكتروني غير صحيح');
    if (phone.length > 20) errors.push('رقم الهاتف طويل جدًا');
    if (errors.length) return res.status(400).json({ success: false, message: 'بيانات غير صحيحة', errors });

    const existingEmail = queryOne(`SELECT id FROM users
        WHERE LOWER(COALESCE(email,'')) = LOWER(?) AND id != ?`, [email, req.user.id]);
    if (existingEmail) {
        return res.status(409).json({ success: false, message: 'البريد الإلكتروني مستخدم بواسطة حساب آخر' });
    }

    db.run(`UPDATE users
            SET full_name = ?, email = ?, phone = ?, updated_at = datetime('now')
            WHERE id = ?`, [fullName, email, phone, req.user.id]);
    saveDatabase();

    const user = safeUser(queryOne("SELECT * FROM users WHERE id = ?", [req.user.id]));
    sessions[req.token] = user;

    res.json({ success: true, message: 'تم تحديث بيانات الحساب بنجاح', user });
});

app.post('/api/password', requireAuth, (req, res) => {
    const currentPassword = req.body.currentPassword || '';
    const newPassword = req.body.newPassword || '';

    const user = queryOne("SELECT * FROM users WHERE id = ?", [req.user.id]);
    if (!user || user.password !== hashPassword(currentPassword)) {
        return res.status(401).json({ success: false, message: 'كلمة المرور الحالية غير صحيحة' });
    }
    if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return res.status(400).json({ success: false, message: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل وتحتوي حرفًا ورقمًا' });
    }

    db.run(`UPDATE users SET password = ?, updated_at = datetime('now') WHERE id = ?`,
        [hashPassword(newPassword), req.user.id]);
    saveDatabase();

    res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
});

// ==================== CUSTOMER DASHBOARD API ====================
app.get('/api/dashboard', requireAuth, (req, res) => {
    const publishedContent = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'published'")?.c || 0;
    let messagesCount = 0;
    let recentMessages = [];

    if (req.user.email) {
        messagesCount = queryOne("SELECT COUNT(*) AS c FROM messages WHERE LOWER(email) = LOWER(?)", [req.user.email])?.c || 0;
        recentMessages = queryAll(`SELECT id, name, email, subject, message, created_at
            FROM messages WHERE LOWER(email) = LOWER(?) ORDER BY id DESC LIMIT 5`, [req.user.email]);
    }

    const requestsCount = queryOne("SELECT COUNT(*) AS c FROM requests WHERE user_id = ?", [req.user.id])?.c || 0;
    const recentRequests = queryAll(`SELECT id, title, status, priority, created_at
        FROM requests WHERE user_id = ? ORDER BY id DESC LIMIT 5`, [req.user.id]);

    res.json({
        success: true,
        user: req.user,
        stats: { publishedContent, messagesCount, requestsCount },
        recentMessages,
        recentRequests
    });
});

// ==================== CONTENT CRUD API ====================
app.get('/api/content', (req, res) => {
    const { category, status, search } = req.query;
    let sql = "SELECT * FROM content_items WHERE 1=1";
    const params = [];
    if (category) { sql += " AND category = ?"; params.push(category); }
    if (status) { sql += " AND status = ?"; params.push(status); }
    if (search) { sql += " AND (title LIKE ? OR description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }
    sql += " ORDER BY id DESC";
    res.json({ success: true, data: queryAll(sql, params) });
});

app.get('/api/content/:id', (req, res) => {
    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    if (!item) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    res.json({ success: true, data: item });
});

app.post('/api/content', requireAuth, requireAdmin, (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    if (!title || !category) return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });

    const stmt = db.prepare("INSERT INTO content_items (title, category, description, image, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
    stmt.run([title, category, description ?? '', image ?? 'images/web-dev.png', icon ?? null, status ?? 'published']);
    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    stmt.free();
    saveDatabase();

    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [newId]);
    res.status(201).json({ success: true, message: 'تمت إضافة العنصر بنجاح', data: item });
});

app.put('/api/content/:id', requireAuth, requireAdmin, (req, res) => {
    const { title, category, description, image, icon, status } = req.body;
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    if (!title || !category) return res.status(400).json({ success: false, message: 'العنوان والتصنيف مطلوبان' });

    db.run(`UPDATE content_items SET title = ?, category = ?, description = ?, image = ?, icon = ?, status = ?, updated_at = datetime('now')
            WHERE id = ?`, [title, category, description || '', image || '', icon || null, status || 'published', req.params.id]);
    saveDatabase();

    const item = queryOne("SELECT * FROM content_items WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: 'تم تحديث العنصر بنجاح', data: item });
});

app.delete('/api/content/:id', requireAuth, requireAdmin, (req, res) => {
    const existing = queryOne("SELECT id FROM content_items WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    db.run("DELETE FROM content_items WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف العنصر بنجاح' });
});

// ==================== SERVICES API (TASK 6) ====================
// Public: active services only (used by the public website)
app.get('/api/services', (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM services WHERE status = 'active' ORDER BY id ASC") });
});

// Admin: all services (active + inactive). NOTE: /all must be registered BEFORE /:id
app.get('/api/services/all', requireAuth, requireAdmin, (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM services ORDER BY id DESC") });
});

app.get('/api/services/:id', requireAuth, requireAdmin, (req, res) => {
    const s = queryOne("SELECT * FROM services WHERE id = ?", [req.params.id]);
    if (!s) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    res.json({ success: true, data: s });
});

app.post('/api/services', requireAuth, requireAdmin, (req, res) => {
    const { title, description, icon, image, features, status } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ success: false, message: 'اسم الخدمة مطلوب' });
    const stmt = db.prepare("INSERT INTO services (title, description, icon, image, features, status) VALUES (?, ?, ?, ?, ?, ?)");
    stmt.run([title.trim(), description || '', icon || 'fa-code', image || 'images/web-dev.png', features || '', status === 'inactive' ? 'inactive' : 'active']);
    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    stmt.free();
    saveDatabase();
    res.status(201).json({ success: true, message: 'تمت إضافة الخدمة بنجاح', data: queryOne("SELECT * FROM services WHERE id = ?", [newId]) });
});

app.put('/api/services/:id', requireAuth, requireAdmin, (req, res) => {
    const existing = queryOne("SELECT id FROM services WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    const { title, description, icon, image, features, status } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ success: false, message: 'اسم الخدمة مطلوب' });
    db.run(`UPDATE services SET title=?, description=?, icon=?, image=?, features=?, status=?, updated_at=datetime('now') WHERE id=?`,
        [title.trim(), description || '', icon || 'fa-code', image || '', features || '', status === 'inactive' ? 'inactive' : 'active', req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم تحديث الخدمة بنجاح', data: queryOne("SELECT * FROM services WHERE id = ?", [req.params.id]) });
});

app.delete('/api/services/:id', requireAuth, requireAdmin, (req, res) => {
    const existing = queryOne("SELECT id FROM services WHERE id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ success: false, message: 'الخدمة غير موجودة' });
    db.run("DELETE FROM services WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الخدمة بنجاح' });
});

// ==================== STATS API ====================
app.get('/api/stats', (req, res) => {
    const total = queryOne("SELECT COUNT(*) AS c FROM content_items")['c'];
    const published = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'published'")['c'];
    const drafts = queryOne("SELECT COUNT(*) AS c FROM content_items WHERE status = 'draft'")['c'];
    const byCategory = queryAll("SELECT category, COUNT(*) AS count FROM content_items GROUP BY category");
    res.json({ success: true, data: { total, published, drafts, byCategory } });
});

// ==================== CONTACT MESSAGES API ====================
app.post('/api/messages', (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    if (!name || !email || !message) {
        return res.status(400).json({ success: false, message: 'الاسم والبريد والرسالة مطلوبة' });
    }
    db.run("INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)",
        [name, email, phone || '', subject || '', message]);
    saveDatabase();
    res.status(201).json({ success: true, message: 'تم إرسال رسالتك بنجاح' });
});

app.get('/api/messages', requireAuth, requireAdmin, (req, res) => {
    res.json({ success: true, data: queryAll("SELECT * FROM messages ORDER BY id DESC") });
});

app.delete('/api/messages/:id', requireAuth, requireAdmin, (req, res) => {
    db.run("DELETE FROM messages WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم حذف الرسالة' });
});

// ==================== TASK 7: CUSTOMER REQUEST MANAGEMENT API ====================
// Status workflow: pending -> in_review -> in_progress -> completed | cancelled
const REQUEST_STATUSES = ['pending', 'in_review', 'in_progress', 'completed', 'cancelled'];
const PRIORITIES = ['low', 'medium', 'high'];

function requestWithCustomer(r) {
    return {
        ...r,
        customer_name: r.customer_name || null,
        customer_email: r.customer_email || null,
        service_title: r.service_title || null
    };
}

// Customer-side: submit a new service request (saved to DB with initial status 'pending')
app.post('/api/requests', requireAuth, (req, res) => {
    const title = (req.body.title || '').trim();
    const description = (req.body.description || '').trim();
    const serviceId = req.body.serviceId ? parseInt(req.body.serviceId) : null;
    const priority = PRIORITIES.includes(req.body.priority) ? req.body.priority : 'medium';

    if (!title || title.length < 5) {
        return res.status(400).json({ success: false, message: 'عنوان الطلب مطلوب (5 أحرف على الأقل)' });
    }
    if (!description || description.length < 10) {
        return res.status(400).json({ success: false, message: 'وصف الطلب مطلوب (10 أحرف على الأقل)' });
    }
    if (serviceId) {
        const svc = queryOne("SELECT id FROM services WHERE id = ? AND status = 'active'", [serviceId]);
        if (!svc) return res.status(400).json({ success: false, message: 'الخدمة المحددة غير متوفرة' });
    }

    db.run(`INSERT INTO requests (user_id, service_id, title, description, priority, status)
            VALUES (?, ?, ?, ?, ?, 'pending')`,
        [req.user.id, serviceId, title, description, priority]);
    saveDatabase();

    const newId = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
    const item = queryOne(`SELECT r.*, s.title AS service_title FROM requests r
                           LEFT JOIN services s ON s.id = r.service_id WHERE r.id = ?`, [newId]);
    res.status(201).json({ success: true, message: 'تم إرسال طلبك بنجاح وسيتم مراجعته من فريق الشركة', data: item });
});

// Customer-side: my own requests
app.get('/api/requests/mine', requireAuth, (req, res) => {
    const rows = queryAll(`SELECT r.*, s.title AS service_title FROM requests r
                           LEFT JOIN services s ON s.id = r.service_id
                           WHERE r.user_id = ? ORDER BY r.id DESC`, [req.user.id]);
    res.json({ success: true, data: rows });
});

// ==================== TASK 8: SEARCH & FILTERING (BACKEND-DRIVEN, NO HARDCODED DATA) ====================
// Company-side: list ALL requests with search + multi-criteria filters.
// Every filter is applied in SQL on the real database.
app.get('/api/requests', requireAuth, requireAdmin, (req, res) => {
    const { search, status, priority, service_id, date_from, date_to, sort } = req.query;

    let sql = `SELECT r.*, u.full_name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
                      s.title AS service_title
               FROM requests r
               JOIN users u ON u.id = r.user_id
               LEFT JOIN services s ON s.id = r.service_id
               WHERE 1=1`;
    const params = [];

    // Free-text search: matches request title/description OR customer name/email
    if (search && search.trim()) {
        sql += ` AND (r.title LIKE ? OR r.description LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
        const q = `%${search.trim()}%`;
        params.push(q, q, q, q);
    }
    // Filters (multi-criteria, combinable)
    if (status && REQUEST_STATUSES.includes(status)) { sql += " AND r.status = ?"; params.push(status); }
    if (priority && PRIORITIES.includes(priority)) { sql += " AND r.priority = ?"; params.push(priority); }
    if (service_id && !isNaN(parseInt(service_id))) { sql += " AND r.service_id = ?"; params.push(parseInt(service_id)); }
    if (date_from) { sql += " AND date(r.created_at) >= date(?)"; params.push(date_from); }
    if (date_to) { sql += " AND date(r.created_at) <= date(?)"; params.push(date_to); }

    // Sorting (white-listed)
    const sortMap = {
        newest: 'r.id DESC', oldest: 'r.id ASC',
        priority: `CASE r.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, r.id DESC`,
        status: 'r.status ASC, r.id DESC'
    };
    sql += " ORDER BY " + (sortMap[sort] || sortMap.newest);

    const data = queryAll(sql, params).map(requestWithCustomer);

    // Filter-aware summary stats (so numbers always match the visible results)
    const counts = {};
    REQUEST_STATUSES.forEach(s => counts[s] = 0);
    queryAll(`SELECT r.status, COUNT(*) AS c FROM requests r JOIN users u ON u.id = r.user_id WHERE 1=1` +
        buildWhere({ search, status, priority, service_id, date_from, date_to }).clause +
        " GROUP BY r.status",
        buildWhere({ search, status, priority, service_id, date_from, date_to }).params)
        .forEach(row => counts[row.status] = row.c);

    res.json({ success: true, data, total: data.length, counts });
});

function buildWhere({ search, status, priority, service_id, date_from, date_to }) {
    let clause = ''; const params = [];
    if (search && search.trim()) {
        clause += ` AND (r.title LIKE ? OR r.description LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
        const q = `%${search.trim()}%`;
        params.push(q, q, q, q);
    }
    if (status && REQUEST_STATUSES.includes(status)) { clause += " AND r.status = ?"; params.push(status); }
    if (priority && PRIORITIES.includes(priority)) { clause += " AND r.priority = ?"; params.push(priority); }
    if (service_id && !isNaN(parseInt(service_id))) { clause += " AND r.service_id = ?"; params.push(parseInt(service_id)); }
    if (date_from) { clause += " AND date(r.created_at) >= date(?)"; params.push(date_from); }
    if (date_to) { clause += " AND date(r.created_at) <= date(?)"; params.push(date_to); }
    return { clause, params };
}

// Company-side: single request detail
app.get('/api/requests/:id', requireAuth, (req, res) => {
    const r = queryOne(`SELECT r.*, u.full_name AS customer_name, u.email AS customer_email,
                               u.phone AS customer_phone, s.title AS service_title
                        FROM requests r
                        JOIN users u ON u.id = r.user_id
                        LEFT JOIN services s ON s.id = r.service_id
                        WHERE r.id = ?`, [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (req.user.role !== 'admin' && r.user_id !== req.user.id) {
        return res.status(403).json({ success: false, message: 'لا يمكنك عرض طلبات عملاء آخرين' });
    }
    res.json({ success: true, data: r });
});

// Customer-side: edit/cancel own request (only while pending)
app.put('/api/requests/:id', requireAuth, (req, res) => {
    const r = queryOne("SELECT * FROM requests WHERE id = ?", [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (r.user_id !== req.user.id) return res.status(403).json({ success: false, message: 'لا يمكنك تعديل طلبات الآخرين' });

    const title = (req.body.title || '').trim();
    const description = (req.body.description || '').trim();
    const priority = PRIORITIES.includes(req.body.priority) ? req.body.priority : r.priority;
    const status = req.body.status;

    // Customer can cancel their own pending/in_review request
    if (status === 'cancelled') {
        if (!['pending', 'in_review'].includes(r.status)) {
            return res.status(400).json({ success: false, message: 'لا يمكن إلغاء طلب بدأت معالجته' });
        }
        db.run(`UPDATE requests SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`, [r.id]);
        saveDatabase();
        return res.json({ success: true, message: 'تم إلغاء الطلب', data: queryOne("SELECT * FROM requests WHERE id = ?", [r.id]) });
    }

    if (r.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'لا يمكن تعديل الطلب بعد بدء معالجته' });
    }
    if (title.length < 5 || description.length < 10) {
        return res.status(400).json({ success: false, message: 'عنوان الطلب (5+) ووصفه (10+) مطلوبان' });
    }
    db.run(`UPDATE requests SET title = ?, description = ?, priority = ?, updated_at = datetime('now') WHERE id = ?`,
        [title, description, priority, r.id]);
    saveDatabase();
    res.json({ success: true, message: 'تم تحديث الطلب بنجاح', data: queryOne("SELECT * FROM requests WHERE id = ?", [r.id]) });
});

// Company-side: update request status + admin notes (full status workflow)
app.put('/api/requests/:id/status', requireAuth, requireAdmin, (req, res) => {
    const r = queryOne("SELECT * FROM requests WHERE id = ?", [req.params.id]);
    if (!r) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });

    const status = req.body.status;
    if (!REQUEST_STATUSES.includes(status)) {
        return res.status(400).json({ success: false, message: 'حالة غير صحيحة', valid: REQUEST_STATUSES });
    }
    const notes = (req.body.adminNotes || '').trim();

    db.run(`UPDATE requests SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?`,
        [status, notes, r.id]);
    saveDatabase();

    const updated = queryOne(`SELECT r.*, u.full_name AS customer_name, u.email AS customer_email,
                                     s.title AS service_title
                              FROM requests r JOIN users u ON u.id = r.user_id
                              LEFT JOIN services s ON s.id = r.service_id WHERE r.id = ?`, [r.id]);
    res.json({ success: true, message: 'تم تحديث حالة الطلب بنجاح', data: updated });
});

// ==================== START ====================
app.get('/api/health', (req, res) => res.json({ success: true, status: 'running' }));

app.use('/api', (req, res) => res.status(404).json({ success: false, message: 'API endpoint غير موجود' }));

(async () => {
    await loadDatabase();
    app.listen(PORT, () => {
        console.log('=================================================');
        console.log('  NexaTech Solutions - Backend Running');
        console.log(`  Website:          http://localhost:${PORT}`);
        console.log(`  Customer Dashboard: http://localhost:${PORT}/dashboard.html`);
        console.log(`  Admin Panel:      http://localhost:${PORT}/admin`);
        console.log(`  Requests Mgmt:    http://localhost:${PORT}/admin/requests.html`);
        console.log(`  New Request:      http://localhost:${PORT}/request.html`);
        console.log('  Admin Login:      admin / admin123');
        console.log('=================================================');
    });
})();
