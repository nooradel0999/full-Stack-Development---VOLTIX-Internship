# NexaTech Solutions — Task 3 + Task 5 + Task 6

نظام Full Stack متكامل يحتوي على:

- الموقع الرئيسي.
- نظام Authentication: تسجيل دخول وإنشاء حساب.
- Customer Dashboard محمية ومتصلة بالـ Backend وقاعدة بيانات SQLite.
- لوحة إدارة المحتوى للمدير.
- نظام إدارة خدمات الشركة (Task 6) مع ربط تلقائي بالموقع العام.

## طريقة التشغيل

### ويندوز
شغّل `run.bat` بالدبل-كليك.

### يدويًا
```bash
cd server
npm install
npm start
```

ثم افتح:

- الموقع: http://localhost:3000
- لوحة العميل: http://localhost:3000/dashboard.html
- لوحة الإدارة: http://localhost:3000/admin
- بيانات المدير: `admin / admin123`
- إدارة الخدمات: http://localhost:3000/admin/services.html

## ملاحظات Task 5 — Customer Dashboard

- لا يمكن الوصول إلى Dashboard بدون تسجيل الدخول.
- بيانات المستخدم تُجلب من `/api/me` و`/api/dashboard` من قاعدة البيانات.
- يستطيع المستخدم تعديل: الاسم الكامل، البريد الإلكتروني، رقم الهاتف.
- يستطيع المستخدم تغيير كلمة المرور بعد إدخال كلمة المرور الحالية.
- اسم المستخدم والدور وتاريخ الإنشاء للعرض فقط.
- Dashboard تتصل بجداول: `users` و`messages` و`content_items`.

## الـ API المضاف لـ Task 5

| Method | Endpoint | الوظيفة |
|---|---|---|
| POST | `/api/register` | إنشاء حساب عميل |
| POST | `/api/login` | تسجيل الدخول باسم المستخدم أو البريد |
| POST | `/api/logout` | تسجيل الخروج |
| GET | `/api/me` | بيانات المستخدم الحالي |
| PUT | `/api/profile` | تعديل بيانات الحساب |
| POST | `/api/password` | تغيير كلمة المرور |
| GET | `/api/dashboard` | بيانات Dashboard من قاعدة البيانات |

## قاعدة البيانات

جداول النظام:

- `users`
- `content_items`
- `messages`

الملف: `data/nexatech.db` ويُنشأ تلقائيًا عند أول تشغيل.


## ملاحظات Task 6 — Company Service Management

- جدول جديد `services` في قاعدة البيانات (اسم، وصف، أيقونة، صورة، مميزات، حالة).
- لوحة داخلية جديدة: `admin/services.html` — إضافة/عرض/تعديل/حذف الخدمات مع بحث وفلترة.
- العمليات محمية بـ `requireAuth + requireAdmin` — المدير المصرح له فقط.
- الموقع العام يجلب الخدمات من `GET /api/services` (النشطة فقط) — لا خدمات ثابتة في الـ Frontend.
- أي تعديل في لوحة الخدمات يظهر تلقائيًا في الموقع فور تحديث الصفحة.
- الحالة `inactive` تخفي الخدمة من الموقع دون حذفها.

## الـ API المضاف لـ Task 6

| Method | Endpoint | الوظيفة |
|---|---|---|
| GET | `/api/services` | الخدمات النشطة (عام — يستخدمه الموقع) |
| GET | `/api/services/all` | كل الخدمات (مدير فقط) |
| GET | `/api/services/:id` | خدمة واحدة (مدير فقط) |
| POST | `/api/services` | إضافة خدمة (مدير فقط) |
| PUT | `/api/services/:id` | تعديل خدمة (مدير فقط) |
| DELETE | `/api/services/:id` | حذف خدمة (مدير فقط) |

جداول النظام الآن: `users`، `content_items`، `messages`، `services`.

إعداد: Nooraleeman Adel Al-shawesh — September 2026
