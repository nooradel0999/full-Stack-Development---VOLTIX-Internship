# NexaTech Solutions — Tasks 3 + 5 + 6 + 7 + 8 + 9

نظام Full Stack متكامل يحتوي على:

- الموقع الرئيسي.
- نظام Authentication: تسجيل دخول وإنشاء حساب.
- Customer Dashboard محمية ومتصلة بالـ Backend وقاعدة بيانات SQLite.
- لوحة إدارة المحتوى للمدير (Task 3).
- نظام إدارة خدمات الشركة (Task 6) مع ربط تلقائي بالموقع العام.
- نظام إدارة طلبات العملاء (Task 7): إرسال الطلب من العميل + إدارته ومتابعته وتحديث حالته من الشركة.
- نظام البحث والفلترة (Task 8): بحث نصي + فلترة متعددة المعايير تنفذ في الـ Backend على قاعدة البيانات الفعلية — بدون أي بيانات Hardcoded في الـ Frontend.
- نظام الأدوار والصلاحيات RBAC (Task 9): مستخدمون بأدوار مختلفة، لكل دور مجموعة صلاحيات محددة، والـ Backend يتحقق من الصلاحية قبل أي عملية محمية.

## طريقة التشغيل

### ويندوز
شغّل `run.bat` بالدبل-كليك.

### يدويًا
```bash
cd server
npm install
npm start
```

ثم افتح:

- الموقع: http://localhost:3000
- إرسال طلب (عميل): http://localhost:3000/request.html
- لوحة العميل: http://localhost:3000/dashboard.html
- لوحة الإدارة: http://localhost:3000/admin
- إدارة طلبات العملاء: http://localhost:3000/admin/requests.html
- إدارة الخدمات: http://localhost:3000/admin/services.html

## حسابات الدخول

| الحساب | اسم المستخدم | كلمة المرور | الدور |
|---|---|---|---|
| المدير | `admin` | `admin123` | admin |
| عميل تجريبي | `customer1` | `Demo1234` | customer |
| موظف تجريبي | `employee1` | `Emp12345` | employee |

## Task 7 — إدارة طلبات العملاء (Customer Request Management)

### جهة العميل
- إرسال طلب خدمة من المنصة عبر `POST /api/requests` — يُحفظ في قاعدة البيانات بالحالة الابتدائية `pending`.
- اختيار الخدمة المطلوبة (من جدول الخدمات الفعلي)، العنوان، الوصف، درجة الأولوية (منخفضة/متوسطة/عالية).
- عرض طلباته `GET /api/requests/mine` مع حالة كل طلب، وإمكانية تعديل الطلب أو إلغائه طالما لم تبدأ معالجته.
- قسم "طلباتي" داخل Customer Dashboard مع عداد الطلبات.

### جهة الشركة (المدير)
- عرض كل الطلبات `GET /api/requests` مع اسم العميل وبياناته والخدمة المرتبطة.
- عرض تفاصيل أي طلب `GET /api/requests/:id`.
- تحديث حالة الطلب أثناء المعالجة `PUT /api/requests/:id/status` عبر دورة حالات كاملة:
  `pending → in_review → in_progress → completed` (أو `cancelled`).
- إضافة ملاحظات المعالجة (admin_notes) كسجل لحالة الطلب.

## Task 8 — البحث والفلترة (Search & Filtering for Company Data)

منفذة في قسم طلبات العملاء في لوحة الشركة، وجميع النتائج تأتي من الـ Backend:

- **بحث نصي** (`search`): يطابق عنوان الطلب أو وصفه أو اسم العميل أو بريده.
- **فلترة متعددة المعايير** (قابلة للدمج كلها معًا):
  - الحالة (`status`) — من قائمة الحالات المعتمدة.
  - الأولوية (`priority`) — عالية/متوسطة/منخفضة.
  - الخدمة (`service_id`) — من جدول الخدمات.
  - النطاق الزمني (`date_from` / `date_to`).
- **ترتيب** (`sort`): الأحدث، الأقدم، حسب الأولوية، حسب الحالة.
- إحصائيات الحالات في الأعلى تتحدث بناءً على نفس معايير الفلترة الحالية.
- كل الاستعلامات تنفذ في SQL على قاعدة البيانات — لا توجد بيانات ثابتة في الـ Frontend.

## Task 9 — الأدوار والصلاحيات (Role-Based Access Control)

### الأدوار الافتراضية
| الدور | الوصف | الصلاحيات |
|---|---|---|
| `admin` | مدير النظام — كل الصلاحيات (دور نظام محمي لا يمكن تعديل صلاحياته أو حذفه) | الكل (14) |
| `employee` | موظف عادي — يعرض بيانات محددة وينفذ عمليات محددة فقط | عرض كل الطلبات، تحديث حالة الطلب، عرض الرسائل، إرسال طلباته |
| `customer` | عميل — يرسل طلباته ويتابعها فقط | إنشاء طلب، عرض طلباته، تعديل/إلغاء طلبه المعلق |

### الـ Backend يفرض الصلاحيات (requirePermission)
- `POST/PUT/DELETE /api/content` ← تتطلب `content.manage`
- `POST/PUT/DELETE /api/services` ← تتطلب `services.manage`
- `GET /api/requests` (كل الطلبات) ← تتطلب `requests.view.all`
- `PUT /api/requests/:id/status` ← تتطلب `requests.update.status`
- `GET /api/messages` ← تتطلب `messages.view` / `DELETE` ← `messages.delete`
- `GET /api/users` ← `users.view` / `PUT /api/users/:id/role` ← `users.manage`
- `GET/POST/PUT/DELETE /api/roles` ← `roles.manage`

### API جديد في Task 9
| Method | Endpoint | الوظيفة |
|---|---|---|
| GET | `/api/me/permissions` | صلاحيات المستخدم الحالي (تستخدمها الواجهة للتكيّف) |
| GET | `/api/permissions` | كتالوج كل الصلاحيات المتاحة |
| GET/POST | `/api/roles` | عرض/إنشاء الأدوار مع صلاحياتها |
| PUT/DELETE | `/api/roles/:name` | تعديل صلاحيات دور / حذف دور مخصص |
| GET | `/api/users` | قائمة المستخدمين (مع صلاحياتهم) |
| PUT | `/api/users/:id/role` | تعيين دور لمستخدم (مع حماية آخر مدير) |

### صفحات الإدارة الجديدة
- `/admin/users.html` — إدارة المستخدمين وتعيين الأدوار
- `/admin/roles.html` — إنشاء الأدوار وتعديل صلاحياتها

## الـ API الكامل

### Task 7
| Method | Endpoint | الوظيفة |
|---|---|---|
| POST | `/api/requests` | العميل يرسل طلب جديد (يُحفظ بالحالة pending) |
| GET | `/api/requests/mine` | طلبات العميل الحالي |
| GET | `/api/requests` | كل الطلبات (مدير فقط) + بحث وفلاتر Task 8 |
| GET | `/api/requests/:id` | تفاصيل طلب (المدير أو صاحب الطلب) |
| PUT | `/api/requests/:id` | العميل يعدّل/يلغي طلبه المعلق |
| PUT | `/api/requests/:id/status` | الشركة تحدّث الحالة والملاحظات (مدير فقط) |

### Task 8 — معاملات الفلترة لـ `GET /api/requests`
| المعامل | الوظيفة |
|---|---|
| `search` | بحث نصي (عنوان/وصف/عميل/بريد) |
| `status` | فلتر الحالة |
| `priority` | فلتر الأولوية |
| `service_id` | فلتر الخدمة |
| `date_from` / `date_to` | فلتر الفترة الزمنية |
| `sort` | newest / oldest / priority / status |

## قاعدة البيانات

جداول النظام: `users`، `content_items`، `messages`، `services`، `requests`، `roles`، `permissions`، `role_permissions`.

الملف: `data/nexatech.db` ويُنشأ/يُحدَّث تلقائيًا عند التشغيل.

إعداد: Nooraleeman Adel Al-shawesh — September 2026
