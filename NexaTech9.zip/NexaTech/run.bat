@echo off
title NexaTech - Full Stack Server
cd /d "%~dp0server"
echo ==========================================
echo   NexaTech Solutions - Tasks 3+5+6+7+8+9
echo   Starting server...
echo   Website:            http://localhost:3000
echo   Customer Dashboard: http://localhost:3000/dashboard.html
echo   Send Request:       http://localhost:3000/request.html
echo   Admin Panel:        http://localhost:3000/admin
echo   Requests Mgmt:      http://localhost:3000/admin/requests.html
echo   Services Mgmt:      http://localhost:3000/admin/services.html
echo   Users ^& Roles:   http://localhost:3000/admin/users.html
echo   Roles ^& Perms:  http://localhost:3000/admin/roles.html
echo   Login: admin / admin123  (employee1 / Emp12345)
echo ==========================================
if not exist node_modules (
    echo Installing dependencies (first time only)...
    call npm install
)
node server.js
pause
